
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Sparkles, Moon, Star, Heart } from 'lucide-react';

const Hero = () => {
  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Floating elements */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute"
            initial={{ 
              x: Math.random() * window.innerWidth,
              y: Math.random() * window.innerHeight,
              opacity: 0 
            }}
            animate={{ 
              y: [0, -30, 0],
              opacity: [0.3, 0.7, 0.3] 
            }}
            transition={{ 
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2 
            }}
          >
            {i % 3 === 0 ? (
              <Star className="h-4 w-4 text-primary/30" />
            ) : i % 3 === 1 ? (
              <Sparkles className="h-3 w-3 text-accent/30" />
            ) : (
              <Moon className="h-5 w-5 text-purple-400/30" />
            )}
          </motion.div>
        ))}
      </div>

      <div className="container mx-auto px-4 text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="max-w-4xl mx-auto"
        >
          <motion.div
            className="mb-8"
            whileHover={{ scale: 1.05 }}
          >
            <img  
              className="w-32 h-32 mx-auto rounded-full border-4 border-primary/30 shadow-2xl floating-animation"
              alt="Tarot Sankara - Lecturas evolutivas del alma"
             src="https://images.unsplash.com/photo-1681809283893-3c7d02f8dc02" />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="text-6xl md:text-8xl font-bold mb-6 text-gradient"
          >
            Tarot Sankara
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="text-xl md:text-2xl mb-8 text-muted-foreground max-w-2xl mx-auto leading-relaxed"
          >
            Descubre los misterios de tu alma a través de lecturas evolutivas de tarot, 
            numerología sagrada y la interpretación profunda de tus sueños
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 0.8 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12"
          >
            <Button 
              size="lg" 
              className="mystical-gradient text-white font-semibold px-8 py-4 text-lg hover:scale-105 transition-transform"
            >
              <Heart className="mr-2 h-5 w-5" />
              Explorar Menú del Alma
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="border-primary/50 text-primary hover:bg-primary/10 px-8 py-4 text-lg"
            >
              <Sparkles className="mr-2 h-5 w-5" />
              Lectura de Tarot
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1, duration: 1 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto"
          >
            <div className="card-mystical p-6 rounded-xl text-center">
              <Moon className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2 text-golden">Lecturas Evolutivas</h3>
              <p className="text-muted-foreground">
                Interpretaciones profundas de las 78 cartas del tarot para tu crecimiento espiritual
              </p>
            </div>

            <div className="card-mystical p-6 rounded-xl text-center">
              <Sparkles className="h-12 w-12 text-accent mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2 text-golden">Menú del Alma</h3>
              <p className="text-muted-foreground">
                Experiencias únicas diseñadas como un menú gastronómico para nutrir tu espíritu
              </p>
            </div>

            <div className="card-mystical p-6 rounded-xl text-center">
              <Star className="h-12 w-12 text-purple-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2 text-golden">Sabiduría Ancestral</h3>
              <p className="text-muted-foreground">
                Numerología y interpretación de sueños para conectar con tu sabiduría interior
              </p>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
