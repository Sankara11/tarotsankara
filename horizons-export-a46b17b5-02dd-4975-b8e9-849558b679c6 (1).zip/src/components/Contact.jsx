
import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Phone, Clock, MapPin, Heart, Star, Sparkles } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const Contact = () => {
  const handleCall = () => {
    toast({
      title: "¡Llamada directa!",
      description: "Marcando 556-073-5969 para tu lectura del alma...",
    });
  };

  const handleWhatsApp = () => {
    const message = encodeURIComponent("Hola, me interesa una lectura del Menú del Alma. ¿Podrías darme más información?");
    window.open(`https://wa.me/5215560735969?text=${message}`, '_blank');
  };

  const services = [
    {
      title: "Lecturas Evolutivas",
      description: "Descubre tu propósito de vida y camino espiritual",
      icon: Heart,
      price: "Desde $300"
    },
    {
      title: "Menú del Alma",
      description: "Experiencias transformadoras diseñadas para tu crecimiento",
      icon: Sparkles,
      price: "Desde $550"
    },
    {
      title: "Sesiones de Sanación",
      description: "Limpieza energética y reconexión con tu esencia",
      icon: Star,
      price: "Desde $800"
    }
  ];

  return (
    <section className="min-h-screen py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl font-bold mb-6 text-gradient">Contacto</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Conecta conmigo para iniciar tu viaje de transformación espiritual. 
            Cada lectura es una experiencia única diseñada especialmente para tu alma.
          </p>
        </motion.div>

        {/* Información de contacto principal */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="max-w-2xl mx-auto mb-12"
        >
          <Card className="tarot-card text-center">
            <CardHeader>
              <CardTitle className="text-3xl text-golden mb-4">
                Reserva tu Lectura del Alma
              </CardTitle>
              <div className="text-center">
                <img  
                  className="w-32 h-32 mx-auto rounded-full border-4 border-primary/30 shadow-2xl mb-6"
                  alt="Tarot Sankara - Contacto para lecturas del alma"
                 src="https://images.unsplash.com/photo-1681809283893-3c7d02f8dc02" />
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-center space-x-4 text-2xl">
                <Phone className="h-8 w-8 text-primary" />
                <span className="font-bold text-golden">556-073-5969</span>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  onClick={handleCall}
                  size="lg"
                  className="golden-gradient text-black font-bold px-8 py-4 text-lg hover:scale-105 transition-transform"
                >
                  <Phone className="mr-2 h-5 w-5" />
                  Llamar Ahora
                </Button>
                <Button
                  onClick={handleWhatsApp}
                  variant="outline"
                  size="lg"
                  className="border-primary/50 text-primary hover:bg-primary/10 px-8 py-4 text-lg"
                >
                  <span className="mr-2">📱</span>
                  WhatsApp
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Servicios disponibles */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-12"
        >
          <h2 className="text-3xl font-bold text-center mb-8 text-golden">
            Servicios Disponibles
          </h2>
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <motion.div
                  key={service.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                >
                  <Card className="menu-item h-full text-center">
                    <CardHeader>
                      <div className="mx-auto mb-4 p-4 bg-primary/20 rounded-full w-fit">
                        <Icon className="h-8 w-8 text-primary" />
                      </div>
                      <CardTitle className="text-xl text-golden">{service.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <p className="text-muted-foreground text-sm leading-relaxed">
                        {service.description}
                      </p>
                      <div className="text-lg font-semibold text-accent">
                        {service.price}
                      </div>
                      <Button
                        onClick={handleCall}
                        variant="outline"
                        size="sm"
                        className="border-primary/50 text-primary hover:bg-primary/10"
                      >
                        Consultar
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Información adicional */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto"
        >
          <Card className="card-mystical">
            <CardHeader>
              <CardTitle className="text-xl text-golden flex items-center">
                <Clock className="mr-2 h-5 w-5" />
                Horarios de Atención
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-muted-foreground">
              <div className="flex justify-between">
                <span>Lunes - Viernes:</span>
                <span className="text-primary">10:00 AM - 8:00 PM</span>
              </div>
              <div className="flex justify-between">
                <span>Sábados:</span>
                <span className="text-primary">10:00 AM - 6:00 PM</span>
              </div>
              <div className="flex justify-between">
                <span>Domingos:</span>
                <span className="text-accent">Solo citas especiales</span>
              </div>
              <div className="mt-4 p-3 bg-secondary/20 rounded-lg">
                <p className="text-sm">
                  💫 <strong>Nota:</strong> Las lecturas se realizan con cita previa. 
                  Llama para agendar tu sesión personalizada.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="card-mystical">
            <CardHeader>
              <CardTitle className="text-xl text-golden flex items-center">
                <MapPin className="mr-2 h-5 w-5" />
                Modalidades de Consulta
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <span className="text-primary">📞</span>
                  <div>
                    <h4 className="font-semibold text-primary">Telefónica</h4>
                    <p className="text-sm">Lecturas completas por teléfono</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <span className="text-accent">💻</span>
                  <div>
                    <h4 className="font-semibold text-accent">Video Llamada</h4>
                    <p className="text-sm">Sesiones por Zoom o WhatsApp Video</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <span className="text-golden">🏠</span>
                  <div>
                    <h4 className="font-semibold text-golden">Presencial</h4>
                    <p className="text-sm">Consultas en persona (Ciudad de México)</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Llamada a la acción final */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="text-center mt-16"
        >
          <Card className="card-mystical max-w-2xl mx-auto">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-gradient mb-4">
                ¿Lista para transformar tu vida?
              </h3>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                Tu alma tiene mensajes importantes que compartir contigo. 
                No esperes más para descubrir tu verdadero propósito y 
                conectar con la sabiduría que llevas dentro.
              </p>
              <Button
                onClick={handleCall}
                size="lg"
                className="mystical-gradient text-white font-bold px-12 py-6 text-xl hover:scale-105 transition-transform pulse-glow"
              >
                <Heart className="mr-3 h-6 w-6" />
                Agenda tu Lectura del Alma
              </Button>
              <p className="text-sm text-muted-foreground mt-4">
                📞 556-073-5969 • Disponible de Lunes a Sábado
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
};

export default Contact;
