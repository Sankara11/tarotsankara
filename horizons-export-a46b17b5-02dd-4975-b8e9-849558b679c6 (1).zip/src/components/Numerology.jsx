
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Calculator, Star, Heart } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const Numerology = () => {
  const [birthDate, setBirthDate] = useState('');
  const [lifePathNumber, setLifePathNumber] = useState(null);
  const [calculation, setCalculation] = useState('');

  const numerologyMeanings = {
    1: {
      title: "El Líder",
      description: "Eres un pionero natural, independiente y ambicioso. Tu propósito es liderar e innovar.",
      traits: ["Liderazgo", "Independencia", "Innovación", "Determinación"],
      challenges: "Evita ser demasiado dominante o impaciente con otros.",
      career: "Emprendimiento, gerencia, política, cualquier campo donde puedas liderar."
    },
    2: {
      title: "El Cooperador",
      description: "Eres diplomático, sensible y trabajas mejor en equipo. Tu don es crear armonía.",
      traits: ["Cooperación", "Diplomacia", "Sensibilidad", "Paciencia"],
      challenges: "No te pierdas en complacer a otros, mantén tu identidad.",
      career: "Consejería, trabajo social, arte, cualquier profesión que requiera colaboración."
    },
    3: {
      title: "El Comunicador",
      description: "Eres creativo, expresivo y optimista. Tu misión es inspirar y entretener a otros.",
      traits: ["Creatividad", "Comunicación", "Optimismo", "Carisma"],
      challenges: "Enfócate en terminar proyectos y evita dispersarte.",
      career: "Arte, escritura, actuación, comunicación, entretenimiento."
    },
    4: {
      title: "El Constructor",
      description: "Eres práctico, confiable y trabajador. Tu propósito es construir bases sólidas.",
      traits: ["Estabilidad", "Trabajo duro", "Organización", "Lealtad"],
      challenges: "Sé más flexible y abierto a nuevas ideas.",
      career: "Arquitectura, ingeniería, administración, cualquier campo que requiera estructura."
    },
    5: {
      title: "El Aventurero",
      description: "Eres libre, versátil y curioso. Tu misión es explorar y experimentar la vida.",
      traits: ["Libertad", "Aventura", "Versatilidad", "Curiosidad"],
      challenges: "Desarrolla compromiso y responsabilidad.",
      career: "Viajes, ventas, periodismo, cualquier profesión que ofrezca variedad."
    },
    6: {
      title: "El Cuidador",
      description: "Eres responsable, amoroso y protector. Tu propósito es nutrir y sanar a otros.",
      traits: ["Responsabilidad", "Compasión", "Servicio", "Familia"],
      challenges: "No te sacrifiques excesivamente por otros.",
      career: "Medicina, enseñanza, trabajo social, cualquier profesión de servicio."
    },
    7: {
      title: "El Buscador",
      description: "Eres analítico, espiritual y introspectivo. Tu misión es buscar la verdad profunda.",
      traits: ["Análisis", "Espiritualidad", "Intuición", "Sabiduría"],
      challenges: "Conecta más con otros y comparte tu sabiduría.",
      career: "Investigación, espiritualidad, ciencia, filosofía."
    },
    8: {
      title: "El Ejecutivo",
      description: "Eres ambicioso, práctico y orientado al éxito material. Tu propósito es lograr el poder constructivo.",
      traits: ["Ambición", "Poder", "Materialismo", "Organización"],
      challenges: "Equilibra el éxito material con valores espirituales.",
      career: "Negocios, finanzas, bienes raíces, cualquier campo empresarial."
    },
    9: {
      title: "El Humanitario",
      description: "Eres compasivo, generoso y visionario. Tu misión es servir a la humanidad.",
      traits: ["Compasión", "Generosidad", "Visión", "Servicio"],
      challenges: "Aprende a recibir tanto como das.",
      career: "Trabajo humanitario, arte, enseñanza, cualquier profesión de servicio global."
    },
    11: {
      title: "El Visionario",
      description: "Eres intuitivo, inspirador y espiritualmente elevado. Tu propósito es iluminar a otros.",
      traits: ["Intuición", "Inspiración", "Espiritualidad", "Visión"],
      challenges: "Mantén los pies en la tierra mientras sigues tu visión.",
      career: "Espiritualidad, arte, sanación, cualquier campo que inspire a otros."
    },
    22: {
      title: "El Maestro Constructor",
      description: "Eres visionario y práctico. Tu misión es materializar grandes sueños para beneficio de todos.",
      traits: ["Visión", "Practicidad", "Liderazgo", "Construcción"],
      challenges: "No te abrumes con la magnitud de tu propósito.",
      career: "Grandes proyectos, liderazgo global, arquitectura, ingeniería a gran escala."
    },
    33: {
      title: "El Maestro Sanador",
      description: "Eres el sanador y maestro supremo. Tu propósito es elevar la conciencia de la humanidad.",
      traits: ["Sanación", "Enseñanza", "Compasión", "Servicio"],
      challenges: "Cuida tu propia energía mientras sanas a otros.",
      career: "Sanación, enseñanza espiritual, trabajo humanitario a gran escala."
    }
  };

  const calculateLifePath = () => {
    if (!birthDate) {
      toast({
        title: "Fecha requerida",
        description: "Por favor ingresa tu fecha de nacimiento",
        variant: "destructive"
      });
      return;
    }

    // Extraer día, mes y año directamente del string de fecha
    const [year, month, day] = birthDate.split('-').map(num => parseInt(num, 10));

    // Función para reducir un número a un solo dígito o número maestro
    const reduceNumber = (num) => {
      while (num > 9 && num !== 11 && num !== 22 && num !== 33) {
        num = num.toString().split('').reduce((sum, digit) => sum + parseInt(digit), 0);
      }
      return num;
    };

    // Función para mostrar el proceso de reducción
    const showReduction = (originalNum) => {
      if (originalNum <= 9 || originalNum === 11 || originalNum === 22 || originalNum === 33) {
        return originalNum.toString();
      }
      
      let steps = [originalNum];
      let current = originalNum;
      
      while (current > 9 && current !== 11 && current !== 22 && current !== 33) {
        current = current.toString().split('').reduce((sum, digit) => sum + parseInt(digit), 0);
        steps.push(current);
      }
      
      return steps.join(' → ');
    };

    // Calcular cada componente
    const reducedDay = reduceNumber(day);
    const reducedMonth = reduceNumber(month);
    const reducedYear = reduceNumber(year);

    // Sumar todos los componentes
    const total = reducedDay + reducedMonth + reducedYear;
    const finalNumber = reduceNumber(total);

    // Mostrar el cálculo paso a paso con formato mejorado
    const calculationSteps = `Fecha seleccionada: ${day}/${month}/${year}

Reducción por componente:
• Día: ${showReduction(day)} = ${reducedDay}
• Mes: ${showReduction(month)} = ${reducedMonth}  
• Año: ${showReduction(year)} = ${reducedYear}

Suma final: ${reducedDay} + ${reducedMonth} + ${reducedYear} = ${total}
Reducción final: ${showReduction(total)} = ${finalNumber}

Tu Número de Camino de Vida es: ${finalNumber}`;

    setCalculation(calculationSteps);
    setLifePathNumber(finalNumber);

    toast({
      title: "¡Cálculo completado!",
      description: `Tu Número de Camino de Vida es ${finalNumber}`,
    });
  };

  const resetCalculation = () => {
    setBirthDate('');
    setLifePathNumber(null);
    setCalculation('');
  };

  return (
    <section className="min-h-screen py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold mb-6 text-gradient">Numerología Sagrada</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Descubre tu Número de Camino de Vida y comprende el propósito profundo de tu alma en esta encarnación
          </p>
        </motion.div>

        {/* Calculadora */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="max-w-md mx-auto mb-12"
        >
          <Card className="card-mystical">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl text-golden flex items-center justify-center">
                <Calculator className="mr-2 h-6 w-6" />
                Calculadora del Camino de Vida
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="birthDate" className="text-primary">
                  Fecha de Nacimiento
                </Label>
                <Input
                  id="birthDate"
                  type="date"
                  value={birthDate}
                  onChange={(e) => setBirthDate(e.target.value)}
                  className="bg-background/50 border-primary/30"
                  placeholder="Selecciona tu fecha de nacimiento"
                />
                {birthDate && (
                  <p className="text-sm text-muted-foreground">
                    Fecha seleccionada: {new Date(birthDate + 'T00:00:00').toLocaleDateString('es-ES', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric'
                    })}
                  </p>
                )}
              </div>

              <div className="flex gap-4">
                <Button
                  onClick={calculateLifePath}
                  className="mystical-gradient text-white font-semibold flex-1"
                  disabled={!birthDate}
                >
                  <Star className="mr-2 h-4 w-4" />
                  Calcular
                </Button>
                {lifePathNumber && (
                  <Button
                    onClick={resetCalculation}
                    variant="outline"
                    className="border-primary/50 text-primary"
                  >
                    Nuevo
                  </Button>
                )}
              </div>

              {calculation && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-secondary/20 p-4 rounded-lg border border-primary/20"
                >
                  <h4 className="font-semibold text-primary mb-3 text-center">
                    🔢 Proceso de Cálculo
                  </h4>
                  <pre className="text-sm text-muted-foreground whitespace-pre-line font-mono leading-relaxed">
                    {calculation}
                  </pre>
                </motion.div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Resultado */}
        {lifePathNumber && numerologyMeanings[lifePathNumber] && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="max-w-4xl mx-auto mb-12"
          >
            <Card className="tarot-card">
              <CardHeader className="text-center">
                <div className="text-6xl font-bold text-golden mb-4">
                  {lifePathNumber}
                </div>
                <CardTitle className="text-3xl text-gradient">
                  {numerologyMeanings[lifePathNumber].title}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="text-center">
                  <img  
                    className="w-48 h-32 mx-auto rounded-lg border-2 border-primary/30"
                    alt={`Numerología número ${lifePathNumber} - ${numerologyMeanings[lifePathNumber].title}`}
                   src="https://images.unsplash.com/photo-1695151841300-e03e6d0ff96a" />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-xl font-semibold text-primary mb-2">
                        Descripción
                      </h3>
                      <p className="text-muted-foreground leading-relaxed">
                        {numerologyMeanings[lifePathNumber].description}
                      </p>
                    </div>

                    <div>
                      <h3 className="text-xl font-semibold text-primary mb-2">
                        Características Principales
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {numerologyMeanings[lifePathNumber].traits.map((trait, index) => (
                          <span
                            key={index}
                            className="bg-primary/20 text-primary px-3 py-1 rounded-full text-sm"
                          >
                            {trait}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h3 className="text-xl font-semibold text-accent mb-2">
                        Desafíos a Superar
                      </h3>
                      <p className="text-muted-foreground leading-relaxed">
                        {numerologyMeanings[lifePathNumber].challenges}
                      </p>
                    </div>

                    <div>
                      <h3 className="text-xl font-semibold text-golden mb-2">
                        Carreras Afines
                      </h3>
                      <p className="text-muted-foreground leading-relaxed">
                        {numerologyMeanings[lifePathNumber].career}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Información sobre numerología */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="max-w-4xl mx-auto"
        >
          <Card className="card-mystical">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl text-golden">
                Sobre la Numerología
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p className="leading-relaxed">
                La numerología es una ciencia sagrada que revela los patrones ocultos del universo 
                a través de los números. Tu Número de Camino de Vida se calcula sumando todos los 
                dígitos de tu fecha de nacimiento y representa el propósito principal de tu alma 
                en esta encarnación.
              </p>
              <p className="leading-relaxed">
                Los números maestros (11, 22, 33) no se reducen porque llevan una vibración 
                especial y representan almas con misiones espirituales elevadas.
              </p>
              <div className="grid md:grid-cols-3 gap-4 mt-6">
                <div className="text-center p-4 bg-secondary/20 rounded-lg">
                  <Heart className="h-8 w-8 text-primary mx-auto mb-2" />
                  <h4 className="font-semibold text-primary">Autoconocimiento</h4>
                  <p className="text-sm">Comprende tu naturaleza esencial</p>
                </div>
                <div className="text-center p-4 bg-secondary/20 rounded-lg">
                  <Star className="h-8 w-8 text-accent mx-auto mb-2" />
                  <h4 className="font-semibold text-accent">Propósito</h4>
                  <p className="text-sm">Descubre tu misión de vida</p>
                </div>
                <div className="text-center p-4 bg-secondary/20 rounded-lg">
                  <Calculator className="h-8 w-8 text-golden mx-auto mb-2" />
                  <h4 className="font-semibold text-golden">Guía</h4>
                  <p className="text-sm">Recibe orientación para tu camino</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
};

export default Numerology;
