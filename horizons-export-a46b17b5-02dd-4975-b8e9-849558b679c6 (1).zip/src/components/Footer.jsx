
import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Star, Moon, Sparkles } from 'lucide-react';

const Footer = () => {
  return (
    <motion.footer
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 1 }}
      className="bg-background/80 backdrop-blur-lg border-t border-border mt-20"
    >
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-3 gap-8 text-center md:text-left">
          {/* Logo y descripción */}
          <div className="space-y-4">
            <div className="flex items-center justify-center md:justify-start space-x-2">
              <Sparkles className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold text-gradient">Tarot Sankara</span>
            </div>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Lecturas evolutivas del alma que te conectan con tu propósito de vida 
              y te guían hacia tu máximo potencial espiritual.
            </p>
            <div className="flex justify-center md:justify-start space-x-4">
              <Heart className="h-5 w-5 text-primary" />
              <Star className="h-5 w-5 text-accent" />
              <Moon className="h-5 w-5 text-purple-400" />
            </div>
          </div>

          {/* Servicios */}
          <div className="space-y-4">
            <span className="text-lg font-semibold text-golden">Servicios</span>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p>• Lecturas de Tarot Evolutivas</p>
              <p>• Menú del Alma</p>
              <p>• Numerología Sagrada</p>
              <p>• Interpretación de Sueños</p>
              <p>• Sesiones de Sanación</p>
            </div>
          </div>

          {/* Contacto */}
          <div className="space-y-4">
            <span className="text-lg font-semibold text-golden">Contacto</span>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p className="flex items-center justify-center md:justify-start">
                📞 <span className="ml-2 text-primary font-semibold">556-073-5969</span>
              </p>
              <p>⏰ Lun - Vie: 10:00 AM - 8:00 PM</p>
              <p>📍 Ciudad de México</p>
              <p>💫 Consultas presenciales y virtuales</p>
            </div>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 text-center">
          <p className="text-sm text-muted-foreground">
            © 2024 Tarot Sankara. Todos los derechos reservados. 
            <span className="text-primary ml-2">✨ Hecho con amor y energía cósmica ✨</span>
          </p>
        </div>
      </div>
    </motion.footer>
  );
};

export default Footer;
