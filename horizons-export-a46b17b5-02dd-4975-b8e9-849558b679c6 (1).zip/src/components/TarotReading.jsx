
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shuffle, RotateCcw, Sparkles, Moon } from 'lucide-react';
import { tarotCards, getRandomCard, getRandomCards } from '@/data/tarotCards';
import { toast } from '@/components/ui/use-toast';

const TarotReading = () => {
  const [selectedCards, setSelectedCards] = useState([]);
  const [readingType, setReadingType] = useState('single');
  const [isRevealed, setIsRevealed] = useState(false);

  const performReading = () => {
    let cards;
    if (readingType === 'single') {
      cards = [getRandomCard()];
    } else if (readingType === 'three') {
      cards = getRandomCards(3);
    } else {
      cards = getRandomCards(5);
    }
    
    // Añadir orientación aleatoria
    const cardsWithOrientation = cards.map(card => ({
      ...card,
      isReversed: Math.random() > 0.5
    }));
    
    setSelectedCards(cardsWithOrientation);
    setIsRevealed(false);
    
    setTimeout(() => setIsRevealed(true), 500);
  };

  const resetReading = () => {
    setSelectedCards([]);
    setIsRevealed(false);
  };

  const getReadingTitle = () => {
    switch (readingType) {
      case 'single': return 'Carta del Día';
      case 'three': return 'Lectura de Tres Cartas';
      case 'celtic': return 'Cruz Celta Simplificada';
      default: return 'Lectura de Tarot';
    }
  };

  const getCardPositionLabel = (index) => {
    if (readingType === 'three') {
      return ['Pasado', 'Presente', 'Futuro'][index];
    } else if (readingType === 'celtic') {
      return ['Situación Actual', 'Desafío', 'Pasado', 'Futuro Posible', 'Corona'][index];
    }
    return '';
  };

  return (
    <section className="min-h-screen py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold mb-6 text-gradient">Lecturas de Tarot Evolutivas</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Descubre los mensajes que el universo tiene para ti a través de las cartas sagradas del tarot
          </p>
        </motion.div>

        {/* Selector de tipo de lectura */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex justify-center mb-8"
        >
          <div className="flex flex-wrap gap-4">
            <Button
              variant={readingType === 'single' ? 'default' : 'outline'}
              onClick={() => setReadingType('single')}
              className="flex items-center space-x-2"
            >
              <Moon className="h-4 w-4" />
              <span>Carta del Día</span>
            </Button>
            <Button
              variant={readingType === 'three' ? 'default' : 'outline'}
              onClick={() => setReadingType('three')}
              className="flex items-center space-x-2"
            >
              <Sparkles className="h-4 w-4" />
              <span>Pasado, Presente, Futuro</span>
            </Button>
            <Button
              variant={readingType === 'celtic' ? 'default' : 'outline'}
              onClick={() => setReadingType('celtic')}
              className="flex items-center space-x-2"
            >
              <Sparkles className="h-4 w-4" />
              <span>Cruz Celta</span>
            </Button>
          </div>
        </motion.div>

        {/* Botones de acción */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="flex justify-center gap-4 mb-12"
        >
          <Button
            onClick={performReading}
            size="lg"
            className="mystical-gradient text-white font-semibold px-8 py-4"
          >
            <Shuffle className="mr-2 h-5 w-5" />
            Realizar {getReadingTitle()}
          </Button>
          {selectedCards.length > 0 && (
            <Button
              onClick={resetReading}
              variant="outline"
              size="lg"
              className="border-primary/50 text-primary hover:bg-primary/10 px-8 py-4"
            >
              <RotateCcw className="mr-2 h-5 w-5" />
              Nueva Lectura
            </Button>
          )}
        </motion.div>

        {/* Cartas seleccionadas */}
        {selectedCards.length > 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5 }}
            className="max-w-6xl mx-auto"
          >
            <h2 className="text-3xl font-bold text-center mb-8 text-golden">
              {getReadingTitle()}
            </h2>
            
            <div className={`grid gap-8 ${
              selectedCards.length === 1 ? 'grid-cols-1 max-w-md mx-auto' :
              selectedCards.length === 3 ? 'grid-cols-1 md:grid-cols-3' :
              'grid-cols-1 md:grid-cols-3 lg:grid-cols-5'
            }`}>
              {selectedCards.map((card, index) => (
                <motion.div
                  key={`${card.id}-${index}`}
                  initial={{ opacity: 0, rotateY: 180 }}
                  animate={{ 
                    opacity: isRevealed ? 1 : 0.7, 
                    rotateY: isRevealed ? 0 : 180 
                  }}
                  transition={{ delay: index * 0.2 + 0.5 }}
                  className="relative"
                >
                  <Card className="tarot-card h-full">
                    <CardHeader className="text-center pb-4">
                      <CardTitle className="text-xl text-golden">
                        {card.name}
                        {getCardPositionLabel(index) && (
                          <div className="text-sm text-muted-foreground mt-1">
                            {getCardPositionLabel(index)}
                          </div>
                        )}
                      </CardTitle>
                      {card.isReversed && (
                        <div className="text-sm text-red-400 font-semibold">⟲ Invertida</div>
                      )}
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="text-center">
                        <div className="w-32 h-48 mx-auto rounded-lg border-2 border-primary/30 bg-gradient-to-br from-purple-900/20 to-blue-900/20 flex items-center justify-center">
                          <div className={`text-6xl ${card.isReversed ? 'transform rotate-180' : ''}`}>
                            🔮
                          </div>
                        </div>
                      </div>
                      
                      {isRevealed && (
                        <motion.div
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.2 + 1 }}
                          className="space-y-4"
                        >
                          <div>
                            <h4 className="font-semibold text-primary mb-2">
                              Palabras Clave:
                            </h4>
                            <p className="text-sm text-muted-foreground">
                              {card.isReversed ? card.reversed.keywords : card.upright.keywords}
                            </p>
                          </div>
                          
                          <div>
                            <h4 className="font-semibold text-primary mb-2">
                              Significado:
                            </h4>
                            <p className="text-sm text-muted-foreground">
                              {card.isReversed ? card.reversed.meaning : card.upright.meaning}
                            </p>
                          </div>
                          
                          <div>
                            <h4 className="font-semibold text-primary mb-2">
                              Interpretación Evolutiva:
                            </h4>
                            <p className="text-sm text-muted-foreground leading-relaxed">
                              {card.isReversed ? card.reversed.interpretation : card.upright.interpretation}
                            </p>
                          </div>

                          <div>
                            <h4 className="font-semibold text-primary mb-2">
                              Consejo del Alma:
                            </h4>
                            <p className="text-sm text-muted-foreground leading-relaxed italic">
                              {card.isReversed ? card.reversed.advice : card.upright.advice}
                            </p>
                          </div>
                        </motion.div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Explorar todas las cartas */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="mt-16"
        >
          <h2 className="text-3xl font-bold text-center mb-8 text-golden">
            Explora Todas las Cartas del Tarot
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {tarotCards.map((card) => (
              <Card key={card.id} className="tarot-card hover:scale-105 transition-transform cursor-pointer">
                <CardHeader className="text-center pb-2">
                  <CardTitle className="text-lg text-golden">{card.name}</CardTitle>
                  <div className="text-sm text-muted-foreground">
                    {card.arcana === 'mayor' ? 'Arcano Mayor' : `${card.suit} - Arcano Menor`}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-center">
                    <div className="w-24 h-36 mx-auto rounded-lg border border-primary/30 bg-gradient-to-br from-purple-900/20 to-blue-900/20 flex items-center justify-center">
                      <div className="text-3xl">🔮</div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div>
                      <h5 className="font-semibold text-primary text-sm">Derecha:</h5>
                      <p className="text-xs text-muted-foreground">{card.upright.keywords}</p>
                    </div>
                    <div>
                      <h5 className="font-semibold text-red-400 text-sm">Invertida:</h5>
                      <p className="text-xs text-muted-foreground">{card.reversed.keywords}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default TarotReading;
