
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Search, Moon, Star, Eye, Sparkles } from 'lucide-react';
import { dreamCategories, searchDreams, getRandomDream } from '@/data/dreamMeanings';
import { toast } from '@/components/ui/use-toast';

const DreamInterpretation = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [randomDream, setRandomDream] = useState(null);

  const handleSearch = () => {
    if (!searchQuery.trim()) {
      toast({
        title: "Búsqueda vacía",
        description: "Por favor ingresa un símbolo o elemento de tu sueño",
        variant: "destructive"
      });
      return;
    }

    const results = searchDreams(searchQuery);
    setSearchResults(results);
    setSelectedCategory(null);
    setRandomDream(null);

    if (results.length === 0) {
      toast({
        title: "Sin resultados",
        description: "No se encontraron interpretaciones para ese símbolo. Intenta con otra palabra.",
      });
    }
  };

  const showCategory = (category) => {
    setSelectedCategory(category);
    setSearchResults([]);
    setRandomDream(null);
    setSearchQuery('');
  };

  const getRandomInterpretation = () => {
    const dream = getRandomDream();
    setRandomDream(dream);
    setSearchResults([]);
    setSelectedCategory(null);
    setSearchQuery('');
  };

  const resetSearch = () => {
    setSearchQuery('');
    setSearchResults([]);
    setSelectedCategory(null);
    setRandomDream(null);
  };

  return (
    <section className="min-h-screen py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold mb-6 text-gradient">Interpretación de Sueños</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Descifra los mensajes ocultos de tu subconsciente y comprende lo que tus sueños 
            quieren revelarte sobre tu vida y tu camino espiritual
          </p>
        </motion.div>

        {/* Buscador */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="max-w-md mx-auto mb-8"
        >
          <Card className="card-mystical">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl text-golden flex items-center justify-center">
                <Search className="mr-2 h-6 w-6" />
                Buscar Interpretación
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="dreamSearch" className="text-primary">
                  ¿Qué soñaste?
                </Label>
                <Input
                  id="dreamSearch"
                  type="text"
                  placeholder="Ej: perro, agua, volar, casa..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                  className="bg-background/50 border-primary/30"
                />
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={handleSearch}
                  className="mystical-gradient text-white font-semibold flex-1"
                >
                  <Search className="mr-2 h-4 w-4" />
                  Buscar
                </Button>
                <Button
                  onClick={getRandomInterpretation}
                  variant="outline"
                  className="border-accent/50 text-accent hover:bg-accent/10"
                >
                  <Sparkles className="h-4 w-4" />
                </Button>
              </div>

              {(searchResults.length > 0 || selectedCategory || randomDream) && (
                <Button
                  onClick={resetSearch}
                  variant="ghost"
                  size="sm"
                  className="w-full text-muted-foreground"
                >
                  Limpiar búsqueda
                </Button>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Categorías */}
        {!searchResults.length && !selectedCategory && !randomDream && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mb-12"
          >
            <h2 className="text-3xl font-bold text-center mb-8 text-golden">
              Explora por Categorías
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 max-w-4xl mx-auto">
              {dreamCategories.map((category) => (
                <motion.div
                  key={category.id}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button
                    onClick={() => showCategory(category)}
                    variant="outline"
                    className="h-24 w-full flex flex-col items-center justify-center space-y-2 border-primary/30 hover:bg-primary/10"
                  >
                    <span className="text-2xl">{category.icon}</span>
                    <span className="text-sm">{category.name}</span>
                  </Button>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Sueño aleatorio */}
        {randomDream && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="max-w-2xl mx-auto mb-12"
          >
            <Card className="tarot-card">
              <CardHeader className="text-center">
                <div className="flex items-center justify-center mb-4">
                  <Moon className="h-8 w-8 text-primary mr-2" />
                  <CardTitle className="text-2xl text-golden">Interpretación Aleatoria</CardTitle>
                </div>
                <h3 className="text-3xl font-bold text-gradient">{randomDream.symbol}</h3>
                <p className="text-sm text-muted-foreground">Categoría: {randomDream.category}</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <img  
                    className="w-48 h-32 mx-auto rounded-lg border-2 border-primary/30"
                    alt={`Símbolo de sueño: ${randomDream.symbol}`}
                   src="https://images.unsplash.com/photo-1559842908-e5fd408c048f" />
                </div>
                
                <div>
                  <h4 className="font-semibold text-primary mb-2 flex items-center">
                    <Star className="mr-2 h-4 w-4" />
                    Significado General
                  </h4>
                  <p className="text-muted-foreground leading-relaxed">
                    {randomDream.meaning}
                  </p>
                </div>
                
                <div>
                  <h4 className="font-semibold text-accent mb-2 flex items-center">
                    <Eye className="mr-2 h-4 w-4" />
                    Interpretación Profunda
                  </h4>
                  <p className="text-muted-foreground leading-relaxed">
                    {randomDream.interpretation}
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Resultados de búsqueda */}
        {searchResults.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="max-w-4xl mx-auto"
          >
            <h2 className="text-3xl font-bold text-center mb-8 text-golden">
              Resultados para "{searchQuery}"
            </h2>
            <div className="grid gap-6">
              {searchResults.map((dream, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="tarot-card">
                    <CardHeader>
                      <CardTitle className="text-xl text-golden flex items-center">
                        <Moon className="mr-2 h-5 w-5" />
                        {dream.symbol}
                        <span className="ml-auto text-sm text-muted-foreground">
                          {dream.category}
                        </span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <h4 className="font-semibold text-primary mb-1">Significado:</h4>
                        <p className="text-muted-foreground text-sm">{dream.meaning}</p>
                      </div>
                      <div>
                        <h4 className="font-semibold text-accent mb-1">Interpretación:</h4>
                        <p className="text-muted-foreground text-sm">{dream.interpretation}</p>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Categoría seleccionada */}
        {selectedCategory && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="max-w-4xl mx-auto"
          >
            <h2 className="text-3xl font-bold text-center mb-8 text-golden flex items-center justify-center">
              <span className="text-4xl mr-3">{selectedCategory.icon}</span>
              {selectedCategory.name}
            </h2>
            <div className="grid gap-6">
              {selectedCategory.dreams.map((dream, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="tarot-card">
                    <CardHeader>
                      <CardTitle className="text-xl text-golden">{dream.symbol}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <h4 className="font-semibold text-primary mb-1">Significado:</h4>
                        <p className="text-muted-foreground text-sm">{dream.meaning}</p>
                      </div>
                      <div>
                        <h4 className="font-semibold text-accent mb-1">Interpretación:</h4>
                        <p className="text-muted-foreground text-sm">{dream.interpretation}</p>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Información sobre interpretación de sueños */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="max-w-4xl mx-auto mt-16"
        >
          <Card className="card-mystical">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl text-golden">
                Sobre la Interpretación de Sueños
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p className="leading-relaxed">
                Los sueños son el lenguaje del subconsciente, una ventana hacia nuestro mundo interior 
                que nos revela verdades ocultas, miedos, deseos y guía espiritual. Cada símbolo en 
                nuestros sueños tiene un significado profundo que puede ayudarnos a comprender mejor 
                nuestra vida y nuestro camino.
              </p>
              <p className="leading-relaxed">
                Recuerda que la interpretación de los sueños es personal. Aunque existen significados 
                universales, el contexto de tu vida y tus emociones al soñar son fundamentales para 
                una interpretación precisa.
              </p>
              <div className="grid md:grid-cols-3 gap-4 mt-6">
                <div className="text-center p-4 bg-secondary/20 rounded-lg">
                  <Moon className="h-8 w-8 text-primary mx-auto mb-2" />
                  <h4 className="font-semibold text-primary">Subconsciente</h4>
                  <p className="text-sm">Mensajes de tu mente profunda</p>
                </div>
                <div className="text-center p-4 bg-secondary/20 rounded-lg">
                  <Eye className="h-8 w-8 text-accent mx-auto mb-2" />
                  <h4 className="font-semibold text-accent">Visión</h4>
                  <p className="text-sm">Claridad sobre tu vida</p>
                </div>
                <div className="text-center p-4 bg-secondary/20 rounded-lg">
                  <Star className="h-8 w-8 text-golden mx-auto mb-2" />
                  <h4 className="font-semibold text-golden">Guía</h4>
                  <p className="text-sm">Orientación espiritual</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
};

export default DreamInterpretation;
