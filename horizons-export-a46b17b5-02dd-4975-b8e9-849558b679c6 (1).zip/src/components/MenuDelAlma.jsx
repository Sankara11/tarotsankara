
import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Heart, Star, Sparkles, Phone, Crown, Gift, Baby, DollarSign, Calendar, Moon, Sun } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const MenuDelAlma = () => {
  const menuSections = [
    {
      title: "Bienvenida del Chef Espiritual",
      subtitle: "Querid@ Comensal del Alma",
      description: "Te doy la bienvenida al banquete más sagrado de tu vida: el encuentro contigo mism@ a través de la sabiduría ancestral de las cartas. Soy Sankara, tu guía en este viaje culinario espiritual, donde cada lectura es cuidadosamente preparada como un plato gourmet para nutrir tu alma hambrienta de respuestas.",
      isIntro: true
    },
    {
      title: "Servicio Exprés",
      subtitle: "Encontrar Orientación en tu Vida",
      items: [
        {
          name: "Cuáles tu Lenguaje en y para el Amor",
          description: "Una especialidad exquisita, una síntesis de la cocina ancestral, una mezcla de ingredientes preparada con experiencia mística y bendición ancestral. El tarot que transforma que sana el alma.",
          price: "$1,199",
          duration: "Especialidad",
          icon: Heart
        }
      ]
    },
    {
      title: "Aperitivos del Despertar",
      subtitle: "Entradas ligeras para el autoconocimiento",
      items: [
        {
          name: "Encontrar el Equilibrio",
          description: "Descubre cómo te ves a ti mism@, cómo manejas tu sabiduría, cómo vives tu vida y cómo puedes mejorar tu relación contigo mism@.",
          price: "$399",
          duration: "Entrada",
          icon: Star
        },
        {
          name: "Derribar Tus Muros Emocionales",
          description: "Identifica qué es lo que te impide avanzar, crecer, sanar y evolucionar en tu vida.",
          price: "$299",
          duration: "Entrada",
          icon: Heart
        },
        {
          name: "Cómo Mejorar tu Autoestima Cada Día",
          description: "Descubre las herramientas que necesitas para amarte más, valorarte más, respetarte y autoconocerte. Ideal para comenzar tu viaje de transformación.",
          price: "$399",
          duration: "Entrada",
          icon: Sparkles
        },
        {
          name: "Conocer Tus Egos Más Secretos",
          description: "Revelación profunda de 5 cartas. Descubre qué mensajes inconscientes que manejan tu sabiduría que no conocías. Muy revelador.",
          price: "$499",
          duration: "Entrada",
          icon: Crown
        },
        {
          name: "Identificar el Motivo de tu Infelicidad",
          description: "Revelación profunda de 5 cartas. Descubre qué es lo que te impide ser feliz, qué sombras del corazón con delicadeza y claridad sanadora.",
          price: "$299",
          duration: "Entrada",
          icon: Sun
        }
      ]
    },
    {
      title: "Especialidades de la Casa del Ser",
      subtitle: "Autoconocimiento, bienestar personal y autosuperación",
      items: [
        {
          name: "Encontrar tu Singularidad",
          description: "Revelación completa de 5 cartas del alma que te ayudan a descubrir la esencia de tu camino. Descubrirás de qué viniste al mundo.",
          price: "$499",
          duration: "Especialidad",
          icon: Star,
          featured: true
        },
        {
          name: "Encontrar los Cambios que Necesitas",
          description: "Experiencia mística de 5 cartas evolutivas que transforman definitivamente tu perspectiva con sabiduría ancestral.",
          price: "$399",
          duration: "Especialidad",
          icon: Sparkles
        },
        {
          name: "Motivo de tu Estrés y Resolverlo",
          description: "Revelación mística de 5 cartas sanadoras, preparadas con ingredientes de sabiduría ancestral y servidas con tranquilidad.",
          price: "$499",
          duration: "Especialidad",
          icon: Heart
        },
        {
          name: "Lo que Quiero y Necesito",
          description: "Clarificación profunda de 5 cartas reveladoras, servidas con cristales de discernimiento y una cucharada de propósito.",
          price: "$499",
          duration: "Especialidad",
          icon: Gift
        },
        {
          name: "Auto Boicot (y dejar de hacerlo)",
          description: "Sanación especial de 5 cartas liberadoras que destruyen patrones de auto-sabotaje con sabiduría y sanación ancestral.",
          price: "$399",
          duration: "Especialidad",
          icon: Crown
        }
      ]
    },
    {
      title: "Para los que buscan sanar y brillar",
      subtitle: "Sanación y transformación profunda",
      items: [
        {
          name: "Desarrollar tu Amor Propio y Cuidado Personal",
          description: "Nutritiva selección de 5 cartas sanadoras, marinadas en autocompasión y servidas con aceite esencial de amor propio.",
          price: "$399",
          duration: "Sanación",
          icon: Heart
        },
        {
          name: "Convertir Emociones Dañinas en Emociones Saludables",
          description: "Alquimia fusión de 5 cartas transformadoras, cocidas en el caldero de la transmutación emocional.",
          price: "$499",
          duration: "Sanación",
          icon: Sparkles
        },
        {
          name: "Reconocer la Raíz de un Problema Recurrente",
          description: "Investigación profunda de 5 cartas detectivescas que desentrañan los patrones ocultos con precisión quirúrgica del alma.",
          price: "$499",
          duration: "Sanación",
          icon: Star
        },
        {
          name: "Eliminar aquello de tu Pasado",
          description: "Liberación mística de 5 cartas purificadoras, hervidas con la medicina del tiempo sagrado y límites sanadores.",
          price: "$399",
          duration: "Sanación",
          icon: Crown
        },
        {
          name: "Perdonar y Perdonarme a Través de la Compasión",
          description: "Sanación combinada de 5 cartas compasivas, preparadas con ingredientes de liberación y servidas con bálsamo del perdón.",
          price: "$499",
          duration: "Sanación",
          icon: Heart
        },
        {
          name: "Eliminar máscaras en ti mismo y ante los demás",
          description: "Auténtica alquimia de 5 cartas reveladoras que destruyen falsas identidades con la luz de la verdad interior.",
          price: "$399",
          duration: "Sanación",
          icon: Sun
        }
      ]
    },
    {
      title: "Platillos Estrella",
      subtitle: "Reconocer y Mejorar mis Patrones Emocionales",
      items: [
        {
          name: "Revelar Aquello de lo que No Soy Consciente",
          description: "Reveladora preparación de 6 cartas iluminadoras que traen luz a las sombras inconscientes del ser.",
          price: "$599",
          duration: "Platillo Estrella",
          icon: Crown,
          featured: true
        },
        {
          name: "Identificar bloqueos (y luego, avanzar)",
          description: "Especialidad combinada de 7 cartas desbloqueadoras, servidas con los mejores del progreso espiritual.",
          price: "$699",
          duration: "Platillo Estrella",
          icon: Star
        },
        {
          name: "Crear un Entorno Positivo",
          description: "Armoniosa mezcla de 6 cartas ambientadoras, energizadas y buena vibración.",
          price: "$399",
          duration: "Platillo Estrella",
          icon: Sparkles
        },
        {
          name: "Enfocarte en Agradecer (Para Atraer Más)",
          description: "Poderosa mezcla de 6 cartas de gratitud, servidas con abundancia divina y servidas con manifestaciones milagrosas.",
          price: "$599",
          duration: "Platillo Estrella",
          icon: Gift
        }
      ]
    },
    {
      title: "Delicias del Corazón",
      subtitle: "Amor y relaciones de pareja",
      items: [
        {
          name: "¿Por Qué se rompió Esta Relación?",
          description: "Reveladora mezcla de 6 cartas sanadoras, preparadas con comprensión y servidas con sabiduría del corazón.",
          price: "$399",
          duration: "Delicias",
          icon: Heart
        },
        {
          name: "Identificar un Posible Amor de Pareja",
          description: "Adivinatoria selección de 5 cartas cúpido, aderezadas con posibilidades románticas y servidas con esperanza amorosa.",
          price: "$499",
          duration: "Delicias",
          icon: Heart
        },
        {
          name: "Recuperarse de una Ruptura",
          description: "Nutritiva combinación de 8 cartas sanadoras, cocidas con tratamiento de autocompasión y servidas con una guarnición de esperanza.",
          price: "$899",
          duration: "Delicias",
          icon: Heart
        },
        {
          name: "Encontrar el Ideal de Pareja",
          description: "Preparación fusión de 6 cartas del corazón, marinadas en autoestima y servidas con la bendición del amor verdadero.",
          price: "$599",
          duration: "Delicias",
          icon: Heart
        },
        {
          name: "Amor futuro",
          description: "Profética mezcla de 6 cartas del destino, servidas con una pizca de encuentros divinos.",
          price: "$599",
          duration: "Delicias",
          icon: Heart
        },
        {
          name: "Fortalecer y Mejorar la Relación",
          description: "Nutritiva combinación de 6 cartas de conexión, cocinadas en comunicación auténtica y servidas con una comprensión mutua.",
          price: "$599",
          duration: "Delicias",
          icon: Heart
        },
        {
          name: "Evaluar tu Nueva Relación",
          description: "Analítica preparación de 7 cartas evaluadoras, servidas con la sabiduría del discernimiento amoroso.",
          price: "$699",
          duration: "Delicias",
          icon: Heart
        }
      ]
    },
    {
      title: "Manjar Especial",
      subtitle: "Lecturas únicas y transformadoras",
      items: [
        {
          name: "¿Son el uno para el otro?",
          description: "Una obra maestra culinaria de 11 cartas cuidadosamente seleccionadas para evaluar la compatibilidad, servida con la salsa secreta de la sincronización divina.",
          price: "$999",
          duration: "Manjar Especial",
          icon: Crown,
          premium: true
        },
        {
          name: "¿Los amores ¿Por Qué Me Duelen?",
          description: "Complejo pero equilibrado preparación de 10 cartas sanadoras, preparadas con la balanza de la justicia cósmica.",
          price: "$899",
          duration: "Manjar Especial",
          icon: Heart,
          premium: true
        },
        {
          name: "¿Voy a Encontrar el Verdadero Amor?",
          description: "Esperanzadora fusión de 7 cartas del destino romántico, preparadas con fe en el amor divino.",
          price: "$699",
          duration: "Manjar Especial",
          icon: Heart
        },
        {
          name: "Nunca es Demasiado Tarde",
          description: "Inspiradora combinación de 9 cartas temporales que traen bendición a cualquier edad o etapa de la vida.",
          price: "$899",
          duration: "Manjar Especial",
          icon: Star
        },
        {
          name: "¿Tengo y Conozco a mi Alma Gemela?",
          description: "Mística fusión de 8 cartas definitivas, marinadas en amor universal y servidas con el reconocimiento del alma.",
          price: "$799",
          duration: "Manjar Especial",
          icon: Heart
        },
        {
          name: "Toda la verdad de una relación",
          description: "Reveladora degustación de 12 cartas completas que iluminan cada aspecto de tu vida amorosa.",
          price: "$999",
          duration: "Manjar Especial",
          icon: Crown,
          premium: true
        }
      ]
    },
    {
      title: "Menú Familiar Sagrado",
      subtitle: "Niños y adolescentes",
      items: [
        {
          name: "Ver Sobre tu Hijo",
          description: "Tierna combinación de 7 cartas protectoras, preparadas con amor maternal y sazonadas con sabiduría ancestral.",
          price: "$699",
          duration: "Familiar",
          icon: Baby
        },
        {
          name: "Niños con Mal Comportamiento",
          description: "Comprensiva selección de 6 cartas sanadoras, cocidas en paciencia y servidas con herramientas de crianza consciente.",
          price: "$599",
          duration: "Familiar",
          icon: Baby
        },
        {
          name: "Los Problemas de la Niñez",
          description: "Nutritiva mezcla de 10 cartas comprensivas, cocinadas con protección infantil y servidas con una reducción de comprensión.",
          price: "$999",
          duration: "Familiar",
          icon: Baby
        },
        {
          name: "Rivalidad Entre Hermanos",
          description: "Equilibradora selección de 8 cartas familiares, servidas con la armonía fraterna.",
          price: "$999",
          duration: "Familiar",
          icon: Baby
        },
        {
          name: "Amor Joven - ¿Es Bueno o no Este Amor para mi Hijo/a?",
          description: "Protectora fusión de 7 cartas paternas, preparadas con discernimiento amoroso y sabiduría generacional.",
          price: "$499",
          duration: "Familiar",
          icon: Heart
        }
      ]
    },
    {
      title: "Platillos de Abundancia",
      subtitle: "Dinero, trabajo y finanzas",
      items: [
        {
          name: "Tener Más Dinero",
          description: "Próspera mezcla de 6 cartas financieras, preparadas con mentalidad de abundancia y servidas con la salsa de la prosperidad.",
          price: "$399",
          duration: "Abundancia",
          icon: DollarSign
        },
        {
          name: "Problemas de Dinero",
          description: "Solucionadora combinación de 6 cartas financieras, preparadas con sabiduría económica y servidas con estrategias de prosperidad.",
          price: "$599",
          duration: "Abundancia",
          icon: DollarSign
        },
        {
          name: "¿Es la Carrera o trabajo correcto?",
          description: "Orientadora selección de 5 cartas profesionales, marinadas en propósito profesional y pasión laboral.",
          price: "$499",
          duration: "Abundancia",
          icon: Star
        },
        {
          name: "Iniciar un Nuevo Negocio",
          description: "La receta más completa de nuestro chef místico: 13 cartas emprendedoras, cocinadas en visión empresarial y sabiduría financiera. Cada carta revela un aspecto crucial para el éxito, servido con una guarnición de sincronías divinas favorables.",
          price: "$999",
          duration: "Abundancia",
          icon: Crown,
          premium: true
        },
        {
          name: "Planificación de un negocio",
          description: "Estratégica fusión de 9 cartas organizadoras, marinadas en visión profesional y pasión laboral.",
          price: "$999",
          duration: "Abundancia",
          icon: Star
        },
        {
          name: "Crear una Mejor Relación con el Dinero",
          description: "Sanadora fusión de 7 cartas financieras, preparadas con mentalidad consciente y libre de limitaciones financieras.",
          price: "$699",
          duration: "Abundancia",
          icon: DollarSign
        },
        {
          name: "Tu Situación Financiera",
          description: "Completa evaluación de 10 cartas económicas que radiografían tus finanzas con precisión visionaria.",
          price: "$999",
          duration: "Abundancia",
          icon: Crown,
          premium: true
        },
        {
          name: "Geometría del Dinero",
          description: "Sofisticada arquitectura de 9 cartas financieras, construidas con precisión matemática cósmica y servidas con una salsa de patrones de éxito.",
          price: "$899",
          duration: "Abundancia",
          icon: Star
        },
        {
          name: "¿Por qué Trabajo Me Decido?",
          description: "Decisiva preparación de 6 cartas vocacionales, cocidas con claridad sobre tu nuevo camino profesional ideal.",
          price: "$599",
          duration: "Abundancia",
          icon: Star
        },
        {
          name: "Proyección Profesional",
          description: "Visionaria fusión de 8 cartas de carrera, preparadas con ambición consciente y servidas con estrategias de crecimiento.",
          price: "$799",
          duration: "Abundancia",
          icon: Star
        },
        {
          name: "Resolución de Conflictos en el Ámbito Laboral",
          description: "Pacificadora mezcla de 9 cartas mediadoras, cocinadas en diplomacia armónica y comunicación asertiva.",
          price: "$899",
          duration: "Abundancia",
          icon: Star
        }
      ]
    },
    {
      title: "Ocasiones Mágicas",
      subtitle: "Situaciones y eventos especiales",
      items: [
        {
          name: "Día de Cumpleaños",
          description: "Celebratoria mezcla de 12 cartas festivas, una por cada mes del año solar, servidas con bendiciones cósmicas y la sabiduría de tu nuevo ciclo personal para guiarte durante todo el año que comienza en este mundo.",
          price: "$999",
          duration: "Ocasión Especial",
          icon: Gift,
          premium: true
        },
        {
          name: "Tarot Navideño",
          description: "Festiva selección de 6 cartas navideñas, marinadas en espíritu de celebración y servidas con la magia de las temporadas sagradas.",
          price: "$999",
          duration: "Ocasión Especial",
          icon: Star
        },
        {
          name: "Fases Lunares",
          description: "Nuestra creación más mística: 15 cartas lunares que danzan al ritmo de los ciclos celestiales. Cada carta revela cómo las fases lunares específicas resuenan como la energía selenita influye en tu camino. Preparada con la luz de la luna llena y servida con cristales.",
          price: "$1,099",
          duration: "Ocasión Especial",
          icon: Moon,
          premium: true
        },
        {
          name: "Embarazo y Nacimiento",
          description: "Maternal fusión de 9 cartas de vida, preparadas con amor gestante y servidas con bendiciones para el nuevo ser.",
          price: "$899",
          duration: "Ocasión Especial",
          icon: Baby
        },
        {
          name: "¿Cómo Será Este Viaje?",
          description: "Aventurera combinación de 8 cartas viajeras, preparadas con espíritu nómada y servidas con protección en tus caminos.",
          price: "$799",
          duration: "Ocasión Especial",
          icon: Star
        },
        {
          name: "Descubrir la Causa Emocional de tu Enfermedad",
          description: "Sanadora selección de 5 cartas médicas del alma, preparadas con sabiduría holística y medicina integrativa.",
          price: "$499",
          duration: "Ocasión Especial",
          icon: Heart
        },
        {
          name: "Vida Pasada",
          description: "Antigua receta de 14 cartas temporales que trascienden el tiempo lineal, preparadas con memorias del alma y servidas con la sabiduría de vidas anteriores. Una experiencia gastronómica que conecta pasado, presente y futuro.",
          price: "$999",
          duration: "Ocasión Especial",
          icon: Crown,
          premium: true
        },
        {
          name: "Línea de Luz Para los Próximos 3 Meses",
          description: "Antigua receta de 14 cartas temporales que trascienden el tiempo lineal, preparadas con memorias del alma y servidas con la sabiduría de vidas anteriores. Una experiencia gastronómica que conecta pasado, presente y futuro.",
          price: "$999",
          duration: "Ocasión Especial",
          icon: Star,
          premium: true
        }
      ]
    },
    {
      title: "Comunión Divina",
      subtitle: "Plato único sagrado",
      items: [
        {
          name: "Comunicación con la Deidad Divina",
          description: "Nuestra ofrenda más sublime: 13 cartas sagradas que abren un canal directo con lo Divino. Preparada en gran meditación, consagrada con oraciones ancestrales y servida en el altar de tu corazón. Una experiencia gastronómica que trasciende lo terrenal y alimenta directamente tu conexión con lo sagrado.",
          price: "$999",
          duration: "Comunión Sagrada",
          icon: Crown,
          premium: true,
          sacred: true
        }
      ]
    }
  ];

  const handleContact = () => {
    toast({
      title: "¡Reserva tu Mesa del Alma!",
      description: "Llama al 556-073-5969 para agendar tu lectura evolutiva",
    });
  };

  return (
    <section className="min-h-screen py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-6xl font-bold mb-6 text-gradient">Tarot Menú del Alma</h1>
          <h2 className="text-3xl font-semibold mb-4 text-golden">SANKARA</h2>
          <p className="text-xl text-muted-foreground max-w-4xl mx-auto mb-8">
            El banquete del alma solo se sirve con la sabiduría que viene del corazón
          </p>
          
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="inline-block mb-8"
          >
            <img  
              className="w-80 h-48 mx-auto rounded-xl border-4 border-primary/30 shadow-2xl"
              alt="Menú del Alma Sankara - Carta mística estilo restaurante"
             src="https://images.unsplash.com/photo-1559526146-86d8effb3c51" />
          </motion.div>
        </motion.div>

        {/* Botón de contacto destacado */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-12"
        >
          <Button
            onClick={handleContact}
            size="lg"
            className="golden-gradient text-black font-bold px-12 py-6 text-xl hover:scale-105 transition-transform pulse-glow"
          >
            <Phone className="mr-3 h-6 w-6" />
            ¡Reserva tu mesa espiritual ahora!
          </Button>
          <p className="mt-4 text-lg text-golden font-semibold">556-073-5969</p>
          <p className="text-sm text-muted-foreground italic">
            "Las mejores mesas se reservan rápido... y tu alma merece lo mejor."
          </p>
        </motion.div>

        {/* Notas especiales */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-12"
        >
          <Card className="card-mystical max-w-4xl mx-auto">
            <CardHeader>
              <CardTitle className="text-2xl text-center text-golden">Notas Especiales para el Comensal</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-primary mb-2">🔮 Sobre nuestros ingredientes místicos:</h4>
                  <p className="text-sm text-muted-foreground">
                    Todas nuestras cartas son seleccionadas con la más alta vibración y bendecidas 
                    con intención pura antes de cada lectura.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-primary mb-2">⚡ Preparación en espacio sagrado:</h4>
                  <p className="text-sm text-muted-foreground">
                    Cada lectura es preparada en un ambiente purificado con sahumerios ancestrales 
                    y protegido por oráculos de luz divina.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-primary mb-2">⏰ Tiempo de cocción espiritual:</h4>
                  <p className="text-sm text-muted-foreground">
                    Permitimos que cada carta revele su mensaje en su tiempo divino perfecto, sin 
                    prisas ni presiones mundanas.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-primary mb-2">⚠️ Advertencia de transformación:</h4>
                  <p className="text-sm text-muted-foreground">
                    Todas nuestras lecturas pueden contener trazas de verdad profunda, 
                    transformación inevitable y crecimiento acelerado del alma.
                  </p>
                </div>
              </div>
              <div className="text-center mt-6 p-4 bg-primary/10 rounded-lg">
                <p className="text-primary font-semibold">⭐ Recomendación del Chef Sankara:</p>
                <p className="text-sm text-muted-foreground mt-2">
                  Para una experiencia óptima, se recomienda llegar con el corazón abierto y la 
                  mente receptiva al mensaje del universo.
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Secciones del menú */}
        <div className="space-y-16">
          {menuSections.map((section, sectionIndex) => (
            <motion.div
              key={section.title}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: sectionIndex * 0.1 + 0.4 }}
              className="max-w-6xl mx-auto"
            >
              {section.isIntro ? (
                <Card className="card-mystical mb-12">
                  <CardHeader>
                    <CardTitle className="text-3xl text-center text-golden">{section.title}</CardTitle>
                    <p className="text-xl text-center text-primary font-semibold">{section.subtitle}</p>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground leading-relaxed text-center max-w-4xl mx-auto">
                      {section.description}
                    </p>
                    <div className="mt-6 p-4 bg-secondary/20 rounded-lg">
                      <p className="text-sm text-muted-foreground italic text-center">
                        En este espacio sagrado, las cartas del tarot se convierten en ingredientes 
                        místicos que se combinan para crear el menú perfecto que tu espíritu necesita 
                        en este momento de tu evolución. No es coincidencia que hayas llegado hasta 
                        aquí... tu alma había reservado su mesa en el momento divino perfecto.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <>
                  <div className="text-center mb-8">
                    <h2 className="text-4xl font-bold text-golden mb-2">{section.title}</h2>
                    <p className="text-lg text-muted-foreground italic">{section.subtitle}</p>
                  </div>

                  <div className="grid gap-6">
                    {section.items?.map((item, itemIndex) => {
                      const Icon = item.icon;
                      return (
                        <motion.div
                          key={item.name}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: sectionIndex * 0.1 + itemIndex * 0.1 + 0.6 }}
                        >
                          <Card className={`menu-item ${
                            item.featured ? 'ring-2 ring-primary' : ''
                          } ${
                            item.premium ? 'ring-2 ring-accent' : ''
                          } ${
                            item.sacred ? 'ring-2 ring-golden border-golden/50' : ''
                          }`}>
                            <CardContent className="p-6">
                              <div className="flex items-start justify-between">
                                <div className="flex items-start space-x-4 flex-1">
                                  <div className={`p-3 rounded-full ${
                                    item.sacred ? 'bg-golden/20' :
                                    item.featured ? 'bg-primary/20' : 
                                    item.premium ? 'bg-accent/20' : 
                                    'bg-secondary/20'
                                  }`}>
                                    <Icon className={`h-6 w-6 ${
                                      item.sacred ? 'text-golden' :
                                      item.featured ? 'text-primary' : 
                                      item.premium ? 'text-accent' : 
                                      'text-muted-foreground'
                                    }`} />
                                  </div>
                                  
                                  <div className="flex-1">
                                    <div className="flex items-center space-x-2 mb-2 flex-wrap">
                                      <h3 className="text-xl font-semibold text-golden">{item.name}</h3>
                                      {item.sacred && (
                                        <span className="bg-golden text-black text-xs px-2 py-1 rounded-full font-bold">
                                          Sagrado
                                        </span>
                                      )}
                                      {item.featured && (
                                        <span className="bg-primary text-primary-foreground text-xs px-2 py-1 rounded-full">
                                          Recomendado
                                        </span>
                                      )}
                                      {item.premium && (
                                        <span className="bg-accent text-accent-foreground text-xs px-2 py-1 rounded-full">
                                          Premium
                                        </span>
                                      )}
                                    </div>
                                    <p className="text-muted-foreground mb-3 leading-relaxed">
                                      {item.description}
                                    </p>
                                    <div className="flex items-center space-x-4 text-sm">
                                      <span className="text-primary font-semibold">
                                        {item.duration}
                                      </span>
                                    </div>
                                  </div>
                                </div>
                                
                                <div className="text-right ml-4">
                                  <div className="text-2xl font-bold text-golden mb-2">
                                    {item.price}
                                  </div>
                                  <Button
                                    onClick={handleContact}
                                    variant="outline"
                                    size="sm"
                                    className={`border-primary/50 text-primary hover:bg-primary/10 ${
                                      item.sacred ? 'border-golden/50 text-golden hover:bg-golden/10' : ''
                                    }`}
                                  >
                                    Reservar
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      );
                    })}
                  </div>
                </>
              )}
            </motion.div>
          ))}
        </div>

        {/* Condiciones especiales del servicio sagrado */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0 }}
          className="mt-16"
        >
          <Card className="card-mystical max-w-4xl mx-auto">
            <CardHeader>
              <CardTitle className="text-2xl text-center text-golden">Condiciones Especiales de Nuestro Servicio Sagrado</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-primary mb-2">⏰ TIEMPO DE PREPARACIÓN DIVINA</h4>
                    <p className="text-sm text-muted-foreground">
                      Cada lectura del Menú del Alma es una creación artesanal que requiere tiempo 
                      sagrado para su perfecta elaboración.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-primary mb-2">📅 Tiempo de entrega:</h4>
                    <p className="text-sm text-muted-foreground">
                      24 a 48 horas máximo. Dependiendo de la lista de comensales espirituales en espera.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-primary mb-2">🎯 Garantía:</h4>
                    <p className="text-sm text-muted-foreground">
                      Tu lectura será preparada con la dedicación que merece tu alma.
                    </p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-primary mb-2">📱 FORMATO DE ENTREGA EXCLUSIVO</h4>
                    <p className="text-sm text-muted-foreground">Tu banquete espiritual llegará a ti como:</p>
                    <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                      <li>• Formato PDF profesional con diseño único de TAROT SANKARA</li>
                      <li>• Incluye tu comprobante de compra como certificado de autenticidad</li>
                      <li>• Entrega directa vía WhatsApp o a tu correo electrónico</li>
                    </ul>
                  </div>
                  <div className="text-center p-4 bg-primary/10 rounded-lg">
                    <p className="text-primary font-semibold text-sm">
                      "Las mejores respuestas del universo no se apuran... se cultivan con paciencia divina."
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="text-center border-t pt-6">
                <p className="text-golden font-semibold mb-2">⭐ Sankara - Tu Chef Espiritual ⭐</p>
                <p className="text-sm text-muted-foreground italic">
                  "El alma siempre tiene una mesa reservada en el momento perfecto de su evolución... 
                  y ese momento es AHORA."
                </p>
                <p className="text-xs text-muted-foreground mt-4">
                  No dejes que otro día pase sin alimentar tu alma con las respuestas que tanto necesitas.
                </p>
                <p className="text-sm text-primary mt-2 font-semibold">
                  Con amor y luz infinita, Sankara 💫
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Información de contacto final */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2 }}
          className="mt-12 text-center"
        >
          <Card className="card-mystical max-w-2xl mx-auto">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-golden mb-4">Información de Reservaciones</h3>
              <div className="space-y-3 text-muted-foreground">
                <p className="text-lg">
                  📞 <strong className="text-primary">Reservaciones:</strong> 556-073-5969
                </p>
                <p>
                  📍 <strong className="text-primary">Ubicación:</strong> 369 Callejón del Tarot, Villa Mística
                </p>
                <p>
                  ⏰ <strong className="text-primary">Horarios:</strong> Cocina abierta las 24 horas del espíritu
                </p>
                <p className="text-sm italic mt-4">
                  "Cada 'platillo' de este menú representa una lectura de cartas de tarot personalizada. 
                  Este no es un restaurante tradicional. Aquí, tu lugar en la mesa es un espacio 
                  espiritual a través de consultas de tarot diseñadas para diferentes aspectos de tu vida."
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
};

export default MenuDelAlma;
