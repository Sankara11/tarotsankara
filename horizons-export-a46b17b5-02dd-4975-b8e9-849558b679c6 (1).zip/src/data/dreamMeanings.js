
export const dreamCategories = [
  {
    id: 'animals',
    name: 'Animales',
    icon: '🐺',
    dreams: [
      {
        symbol: 'Perro',
        meaning: 'Lealtad, amistad, protección. Un perro en sueños representa relaciones fieles y tu necesidad de compañía.',
        interpretation: 'Si el perro es amigable, indica que tienes buenos amigos. Si es agresivo, puede representar conflictos con personas cercanas.'
      },
      {
        symbol: 'Gato',
        meaning: 'Independencia, intuición, misterio. Los gatos simbolizan tu lado femenino e intuitivo.',
        interpretation: 'Un gato negro puede indicar que necesitas confiar más en tu intuición. Un gato blanco representa pureza espiritual.'
      },
      {
        symbol: 'Serpiente',
        meaning: 'Transformación, sabiduría, renovación. Las serpientes representan cambios profundos en tu vida.',
        interpretation: 'Una serpiente que muda su piel indica que estás en proceso de transformación personal. Si te muerde, puede representar traición.'
      },
      {
        symbol: 'Águila',
        meaning: 'Libertad, visión superior, poder espiritual. El águila representa tu conexión con lo divino.',
        interpretation: 'Volar con un águila indica elevación espiritual. Ver un águila desde lejos sugiere que necesitas una perspectiva más amplia.'
      },
      {
        symbol: 'Lobo',
        meaning: 'Instinto, liderazgo, conexión con la naturaleza salvaje. Representa tu lado más primitivo.',
        interpretation: 'Un lobo solitario indica independencia. Una manada de lobos sugiere la importancia del trabajo en equipo.'
      }
    ]
  },
  {
    id: 'nature',
    name: 'Naturaleza',
    icon: '🌳',
    dreams: [
      {
        symbol: 'Agua',
        meaning: 'Emociones, purificación, flujo de la vida. El agua representa tu estado emocional.',
        interpretation: 'Agua clara indica emociones equilibradas. Agua turbia sugiere confusión emocional. Tsunamis representan emociones abrumadoras.'
      },
      {
        symbol: 'Fuego',
        meaning: 'Pasión, transformación, destrucción creativa. El fuego simboliza energía vital y cambio.',
        interpretation: 'Un fuego controlado indica pasión dirigida. Un incendio descontrolado sugiere emociones destructivas que necesitas manejar.'
      },
      {
        symbol: 'Montaña',
        meaning: 'Desafíos, metas elevadas, estabilidad. Las montañas representan obstáculos y logros.',
        interpretation: 'Escalar una montaña indica que estás trabajando hacia una meta importante. Ver montañas desde lejos sugiere desafíos futuros.'
      },
      {
        symbol: 'Océano',
        meaning: 'Subconsciente, vastedad, misterio. El océano representa las profundidades de tu psique.',
        interpretation: 'Un océano calmado indica paz interior. Mares tormentosos sugieren turbulencia emocional interna.'
      },
      {
        symbol: 'Bosque',
        meaning: 'Misterio, crecimiento, conexión con la naturaleza. Los bosques representan lo desconocido.',
        interpretation: 'Perderse en un bosque indica confusión en la vida. Encontrar un claro sugiere claridad que está llegando.'
      }
    ]
  },
  {
    id: 'people',
    name: 'Personas',
    icon: '👥',
    dreams: [
      {
        symbol: 'Familia',
        meaning: 'Raíces, apoyo, tradiciones. La familia en sueños representa tu base emocional.',
        interpretation: 'Reuniones familiares felices indican armonía. Conflictos familiares sugieren asuntos no resueltos del pasado.'
      },
      {
        symbol: 'Extraños',
        meaning: 'Aspectos desconocidos de ti mismo, nuevas oportunidades. Los extraños representan lo inexplorado.',
        interpretation: 'Extraños amigables indican nuevas oportunidades. Extraños amenazantes sugieren miedos internos.'
      },
      {
        symbol: 'Niños',
        meaning: 'Inocencia, nuevos comienzos, potencial. Los niños representan tu niño interior.',
        interpretation: 'Niños jugando indican alegría y creatividad. Niños llorando sugieren aspectos heridos de tu niño interior.'
      },
      {
        symbol: 'Ancianos',
        meaning: 'Sabiduría, experiencia, guía espiritual. Los ancianos representan conocimiento ancestral.',
        interpretation: 'Recibir consejos de ancianos indica que necesitas buscar sabiduría. Ancianos enfermos sugieren pérdida de tradiciones.'
      }
    ]
  },
  {
    id: 'objects',
    name: 'Objetos',
    icon: '🔑',
    dreams: [
      {
        symbol: 'Llaves',
        meaning: 'Soluciones, acceso, secretos. Las llaves representan respuestas que buscas.',
        interpretation: 'Encontrar llaves indica que descubrirás soluciones. Perder llaves sugiere que te sientes sin opciones.'
      },
      {
        symbol: 'Espejos',
        meaning: 'Autorreflexión, verdad, percepción. Los espejos representan cómo te ves a ti mismo.',
        interpretation: 'Espejos rotos indican autoimagen fragmentada. Espejos claros sugieren autoconocimiento.'
      },
      {
        symbol: 'Dinero',
        meaning: 'Valor personal, recursos, poder. El dinero representa tu sentido de autoestima.',
        interpretation: 'Encontrar dinero indica reconocimiento de tu valor. Perder dinero sugiere inseguridades sobre tu valía.'
      },
      {
        symbol: 'Libros',
        meaning: 'Conocimiento, aprendizaje, sabiduría. Los libros representan información que necesitas.',
        interpretation: 'Leer libros indica búsqueda de conocimiento. Libros cerrados sugieren secretos por descubrir.'
      },
      {
        symbol: 'Teléfono',
        meaning: 'Comunicación, conexión, mensajes. Los teléfonos representan necesidad de contacto.',
        interpretation: 'Llamadas perdidas indican comunicación bloqueada. Conversaciones claras sugieren buena comunicación.'
      }
    ]
  },
  {
    id: 'actions',
    name: 'Acciones',
    icon: '🏃',
    dreams: [
      {
        symbol: 'Volar',
        meaning: 'Libertad, elevación espiritual, superación de límites. Volar representa liberación.',
        interpretation: 'Volar alto indica libertad espiritual. Dificultad para volar sugiere limitaciones autoimpuestas.'
      },
      {
        symbol: 'Caer',
        meaning: 'Pérdida de control, inseguridad, miedo al fracaso. Caer representa ansiedad.',
        interpretation: 'Caídas largas indican sensación de pérdida de control. Caídas cortas sugieren pequeños miedos.'
      },
      {
        symbol: 'Correr',
        meaning: 'Escape, urgencia, persecución de metas. Correr representa movimiento en la vida.',
        interpretation: 'Correr hacia algo indica persecución de objetivos. Huir corriendo sugiere evitación de problemas.'
      },
      {
        symbol: 'Nadar',
        meaning: 'Navegación emocional, fluidez, adaptación. Nadar representa manejo de emociones.',
        interpretation: 'Nadar fácilmente indica buen manejo emocional. Dificultad para nadar sugiere ahogo emocional.'
      },
      {
        symbol: 'Bailar',
        meaning: 'Alegría, expresión, armonía. Bailar representa celebración de la vida.',
        interpretation: 'Bailar solo indica autoexpresión. Bailar en pareja sugiere armonía en relaciones.'
      }
    ]
  },
  {
    id: 'places',
    name: 'Lugares',
    icon: '🏠',
    dreams: [
      {
        symbol: 'Casa',
        meaning: 'Seguridad, identidad, estado mental. La casa representa tu psique.',
        interpretation: 'Casa ordenada indica estabilidad mental. Casa desordenada sugiere confusión interna.'
      },
      {
        symbol: 'Escuela',
        meaning: 'Aprendizaje, crecimiento, lecciones de vida. La escuela representa desarrollo personal.',
        interpretation: 'Exámenes en la escuela indican que estás siendo probado en la vida. Graduación sugiere completar una fase.'
      },
      {
        symbol: 'Hospital',
        meaning: 'Sanación, cuidado, necesidad de atención. Los hospitales representan recuperación.',
        interpretation: 'Estar en un hospital indica necesidad de sanación. Visitar a alguien sugiere preocupación por otros.'
      },
      {
        symbol: 'Iglesia',
        meaning: 'Espiritualidad, búsqueda de sentido, conexión divina. Las iglesias representan fe.',
        interpretation: 'Orar en una iglesia indica búsqueda espiritual. Iglesia vacía sugiere crisis de fe.'
      },
      {
        symbol: 'Cementerio',
        meaning: 'Finales, transformación, conexión con ancestros. Los cementerios representan transiciones.',
        interpretation: 'Visitar tumbas indica necesidad de cerrar ciclos. Cementerios de noche sugieren miedos sobre la muerte.'
      }
    ]
  }
];

export const getRandomDream = () => {
  const allDreams = dreamCategories.flatMap(category => 
    category.dreams.map(dream => ({ ...dream, category: category.name }))
  );
  const randomIndex = Math.floor(Math.random() * allDreams.length);
  return allDreams[randomIndex];
};

export const searchDreams = (query) => {
  const allDreams = dreamCategories.flatMap(category => 
    category.dreams.map(dream => ({ ...dream, category: category.name }))
  );
  
  return allDreams.filter(dream => 
    dream.symbol.toLowerCase().includes(query.toLowerCase()) ||
    dream.meaning.toLowerCase().includes(query.toLowerCase())
  );
};
