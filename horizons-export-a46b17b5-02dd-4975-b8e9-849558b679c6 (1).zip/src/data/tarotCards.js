
import { majorArcana } from '@/data/majorArcana';
import { cups } from '@/data/minorArcana/cups';
import { swords } from '@/data/minorArcana/swords';
import { wands } from '@/data/minorArcana/wands';
import { pentacles } from '@/data/minorArcana/pentacles';

// Combinar todas las cartas del tarot
export const tarotCards = [
  ...majorArcana,
  ...cups,
  ...swords,
  ...wands,
  ...pentacles
];

// Función para obtener una carta aleatoria
export const getRandomCard = () => {
  const randomIndex = Math.floor(Math.random() * tarotCards.length);
  return tarotCards[randomIndex];
};

// Función para obtener múltiples cartas
export const getRandomCards = (count) => {
  const shuffled = [...tarotCards].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
};
