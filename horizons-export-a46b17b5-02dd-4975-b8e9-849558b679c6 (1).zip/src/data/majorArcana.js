
export const majorArcana = [
  {
    id: 1,
    name: "El Loco",
    arcana: "mayor",
    number: 0,
    upright: {
      keywords: "Nuevos comienzos, espontaneidad, inocencia, espíritu libre, aventura, potencial ilimitado, fe, optimismo, libertad, originalidad",
      meaning: "Nuevos comienzos, espontaneidad, inocencia, espíritu libre, aventura, potencial ilimitado, fe ciega, optimismo, libertad total",
      interpretation: "El Loco representa el inicio de un viaje espiritual extraordinario. Es momento de confiar plenamente en tu intuición divina y dar ese salto de fe que tu alma ha estado esperando. La vida te invita a ser completamente auténtico, a explorar territorios desconocidos sin miedo, y a abrazar la magia de lo impredecible. Tu espíritu libre necesita expresarse ahora.",
      advice: "Confía en el proceso divino. Tu alma sabe exactamente hacia dónde te diriges, incluso cuando tu mente no lo comprenda. Abraza la incertidumbre como tu aliada más poderosa."
    },
    reversed: {
      keywords: "Imprudencia, riesgo innecesario, falta de dirección, caos, irresponsabilidad, negligencia, temeridad, falta de planificación",
      meaning: "Imprudencia, riesgo innecesario, falta de dirección, caos interno, irresponsabilidad, negligencia, temeridad destructiva",
      interpretation: "Cuando aparece invertido, El Loco te advierte sobre la necesidad de encontrar equilibrio entre la espontaneidad y la responsabilidad. Puede indicar que estás actuando de manera demasiado impulsiva, sin considerar las consecuencias, o que necesitas más estructura y planificación antes de tomar decisiones que cambien tu vida.",
      advice: "Pausa y reflexiona antes de actuar. La verdadera libertad viene de tomar decisiones conscientes, no de huir de la responsabilidad."
    }
  },
  {
    id: 2,
    name: "El Mago",
    arcana: "mayor",
    number: 1,
    upright: {
      keywords: "Manifestación, poder personal, habilidad, concentración, voluntad, recursos, talento, comunicación, liderazgo, creatividad",
      meaning: "Manifestación consciente, poder personal activado, habilidades desarrolladas, concentración total, voluntad férrea, recursos disponibles",
      interpretation: "El Mago te recuerda que posees todas las herramientas divinas necesarias para crear la realidad que tu alma desea. Es momento de actuar con determinación absoluta y usar tu voluntad consciente para manifestar tus objetivos más elevados. Tienes acceso a todos los elementos: tierra, agua, fuego y aire. Tu poder de manifestación está en su punto máximo.",
      advice: "Actúa con intención clara y propósito definido. Tus pensamientos, palabras y acciones tienen un poder creativo extraordinario en este momento."
    },
    reversed: {
      keywords: "Manipulación, falta de energía, confusión, mal uso del poder, engaño, falta de concentración, desperdicio de talento",
      meaning: "Manipulación sutil, falta de energía vital, confusión mental, mal uso del poder personal, engaño hacia otros o hacia ti mismo",
      interpretation: "Invertido, El Mago sugiere que puedes estar desperdiciando tu potencial divino o usando tu poder de manera incorrecta. Es momento de reflexionar profundamente sobre tus verdaderas intenciones y asegurarte de que estás alineado con tu propósito más elevado, no con el ego.",
      advice: "Examina tus motivaciones. El verdadero poder viene del servicio amoroso, no de la manipulación o el control sobre otros."
    }
  },
  {
    id: 3,
    name: "La Sacerdotisa",
    arcana: "mayor",
    number: 2,
    upright: {
      keywords: "Intuición, misterio, conocimiento subconsciente, sabiduría interior, espiritualidad, receptividad, paciencia, contemplación",
      meaning: "Intuición desarrollada, misterios revelados, conocimiento subconsciente activado, sabiduría interior profunda, conexión espiritual",
      interpretation: "La Sacerdotisa te invita a sumergirte en las aguas profundas de tu intuición y a explorar los misterios sagrados de tu subconsciente. Es momento de meditar, reflexionar y conectar con tu sabiduría interior más antigua. Ella guarda los secretos del universo femenino y te enseña a confiar en tu conocimiento intuitivo por encima de la lógica.",
      advice: "Silencia la mente y escucha a tu corazón. Las respuestas que buscas ya están dentro de ti, esperando ser descubiertas en el silencio sagrado."
    },
    reversed: {
      keywords: "Secretos ocultos, desconexión de la intuición, superficialidad, ignorar la voz interior, falta de paciencia",
      meaning: "Secretos que necesitan ser revelados, desconexión peligrosa de la intuición, superficialidad emocional, ignorar la voz interior",
      interpretation: "Cuando está invertida, La Sacerdotisa indica que puedes estar ignorando tu voz interior o que hay secretos importantes que necesitan ser revelados para tu crecimiento. También puede señalar que estás viviendo de manera demasiado superficial, sin conectar con tu profundidad espiritual.",
      advice: "Reconecta con tu intuición a través de la meditación y la introspección. Los secretos que temes enfrentar son la clave de tu liberación."
    }
  },
  {
    id: 4,
    name: "La Emperatriz",
    arcana: "mayor",
    number: 3,
    upright: {
      keywords: "Feminidad, belleza, naturaleza, abundancia, maternidad, creatividad, fertilidad, sensualidad, nutrición, crecimiento",
      meaning: "Energía femenina divina, belleza natural, abundancia manifestada, maternidad sagrada, creatividad floreciente, fertilidad en todos los aspectos",
      interpretation: "La Emperatriz representa la energía creativa y nutritiva del universo femenino. Es momento de conectar profundamente con tu lado receptivo, crear belleza en todos los aspectos de tu vida y nutrir tus proyectos con amor incondicional y paciencia maternal. Ella te enseña que la verdadera abundancia viene del amor y la conexión con la naturaleza.",
      advice: "Abraza tu poder creativo y nutritivo. Permite que la abundancia fluya naturalmente hacia ti mientras cuidas amorosamente todo lo que crece en tu vida."
    },
    reversed: {
      keywords: "Dependencia creativa, vacío emocional, falta de crecimiento, negligencia, esterilidad, desconexión de la naturaleza",
      meaning: "Bloqueos creativos profundos, vacío emocional, falta de crecimiento personal, negligencia hacia lo que necesita cuidado",
      interpretation: "Invertida, La Emperatriz puede indicar bloqueos creativos significativos o dificultades para nutrir aspectos importantes de tu vida. También puede señalar una desconexión peligrosa de tu naturaleza femenina o de la abundancia natural que te rodea.",
      advice: "Reconecta con la naturaleza y tu creatividad innata. Dedica tiempo a nutrir tanto a otros como a ti mismo con amor genuino."
    }
  },
  {
    id: 5,
    name: "El Emperador",
    arcana: "mayor",
    number: 4,
    upright: {
      keywords: "Autoridad, estructura, control, paternidad, liderazgo, disciplina, estabilidad, orden, protección, responsabilidad",
      meaning: "Autoridad legítima, estructura sólida, control consciente, liderazgo responsable, disciplina constructiva, estabilidad duradera",
      interpretation: "El Emperador te llama a tomar el control consciente de tu vida con disciplina amorosa y estructura sabia. Es momento de establecer límites claros y saludables, liderar con autoridad compasiva y crear las bases sólidas que necesitas para construir tu imperio personal. Él representa el poder masculino equilibrado y la responsabilidad madura.",
      advice: "Establece límites claros y mantén la disciplina necesaria para alcanzar tus objetivos. Tu liderazgo responsable inspirará a otros a seguir tu ejemplo."
    },
    reversed: {
      keywords: "Tiranía, rigidez, falta de disciplina, abuso de poder, autoritarismo, inflexibilidad, dominación, control excesivo",
      meaning: "Tendencias tiránicas, rigidez mental, falta de disciplina personal, abuso de poder, autoritarismo destructivo, inflexibilidad extrema",
      interpretation: "Cuando aparece invertido, El Emperador advierte sobre el exceso de control o la falta de estructura saludable en tu vida. Puede indicar que estás siendo demasiado rígido o autoritario, o por el contrario, que necesitas más disciplina y orden en tu existencia.",
      advice: "Encuentra el equilibrio entre la autoridad y la compasión. El verdadero liderazgo inspira, no domina ni controla por miedo."
    }
  },
  {
    id: 6,
    name: "El Hierofante",
    arcana: "mayor",
    number: 5,
    upright: {
      keywords: "Tradición, conformidad, moralidad, ética, conocimiento, enseñanza, espiritualidad, sabiduría ancestral, guía espiritual",
      meaning: "Sabiduría tradicional, conformidad consciente, moralidad elevada, enseñanzas espirituales, guía de maestros, conocimiento ancestral",
      interpretation: "El Hierofante representa la sabiduría tradicional y las enseñanzas espirituales que han resistido la prueba del tiempo. Es momento de buscar orientación en maestros espirituales, tradiciones sagradas o sistemas de conocimiento establecidos. Él te conecta con la sabiduría colectiva y te enseña el valor de la disciplina espiritual.",
      advice: "Busca la guía de maestros sabios y honra las tradiciones que han nutrido a la humanidad. La humildad para aprender es el primer paso hacia la maestría."
    },
    reversed: {
      keywords: "Rebelión, subversión, nuevos enfoques, libertad personal, dogmatismo, rigidez espiritual, rechazo a la autoridad",
      meaning: "Rebelión contra tradiciones, subversión de normas, búsqueda de nuevos enfoques espirituales, libertad personal extrema",
      interpretation: "Invertido, El Hierofante te anima a cuestionar las tradiciones que ya no te sirven y encontrar tu propio camino espiritual único. También puede advertir sobre el dogmatismo excesivo o la rigidez espiritual que limita tu crecimiento personal.",
      advice: "Cuestiona todo, pero con sabiduría. Tu camino espiritual único es válido, pero no descartes completamente la sabiduría ancestral."
    }
  },
  {
    id: 7,
    name: "Los Enamorados",
    arcana: "mayor",
    number: 6,
    upright: {
      keywords: "Amor, armonía, relaciones, valores, elecciones, unión, atracción, compromiso, decisiones del corazón, conexión alma",
      meaning: "Amor verdadero, armonía perfecta, relaciones sagradas, valores alineados, elecciones conscientes del corazón, unión divina",
      interpretation: "Los Enamorados representan las decisiones más importantes del corazón y la búsqueda de la unión perfecta. Es momento de elegir basándote en tus valores más profundos y buscar la armonía tanto en las relaciones como en tu interior. Esta carta habla de conexiones que trascienden lo físico y tocan el alma.",
      advice: "Elige con el corazón, pero también con sabiduría. Las decisiones tomadas desde el amor verdadero siempre te llevarán por el camino correcto."
    },
    reversed: {
      keywords: "Desamor, desequilibrio, malas decisiones, conflicto de valores, desarmonía, separación, elecciones incorrectas",
      meaning: "Desamor doloroso, desequilibrio en relaciones, malas decisiones sentimentales, conflicto profundo de valores, desarmonía interna",
      interpretation: "Invertidos, Los Enamorados indican conflictos significativos en las relaciones o dificultades para tomar decisiones importantes del corazón. También puede señalar un desequilibrio entre tus valores y tus acciones, o la necesidad de sanar heridas emocionales profundas.",
      advice: "Examina tus valores y asegúrate de que tus decisiones estén alineadas con tu verdad más profunda. La sanación del corazón es prioritaria."
    }
  },
  {
    id: 8,
    name: "El Carro",
    arcana: "mayor",
    number: 7,
    upright: {
      keywords: "Control, voluntad, victoria, determinación, dirección, triunfo, autocontrol, progreso, conquista, fuerza de voluntad",
      meaning: "Control total, voluntad férrea, victoria merecida, determinación inquebrantable, dirección clara, triunfo sobre obstáculos",
      interpretation: "El Carro simboliza el triunfo absoluto a través de la determinación y el control consciente de todas las fuerzas en tu vida. Es momento de mantener el rumbo con confianza total y avanzar hacia tus objetivos con la certeza de que la victoria está asegurada. Representa el dominio perfecto sobre las emociones y circunstancias.",
      advice: "Mantén el control de todas las fuerzas en tu vida y avanza con determinación inquebrantable. Tu victoria está garantizada si no te desvías del camino."
    },
    reversed: {
      keywords: "Falta de control, falta de dirección, agresión, derrota, obstáculos, pérdida de rumbo, impulsividad destructiva",
      meaning: "Pérdida de control, falta de dirección clara, agresión descontrolada, derrota temporal, obstáculos abrumadores",
      interpretation: "Invertido, El Carro sugiere que puedes estar perdiendo el control de aspectos importantes de tu vida o que necesitas reevaluar completamente tu dirección. También puede indicar que la agresión o la impulsividad están saboteando tu progreso.",
      advice: "Recupera el control paso a paso. Detente, evalúa tu dirección y ajusta tu rumbo antes de continuar avanzando."
    }
  },
  {
    id: 9,
    name: "La Fuerza",
    arcana: "mayor",
    number: 8,
    upright: {
      keywords: "Fuerza interior, coraje, paciencia, compasión, autocontrol, resistencia, valor, gentileza, dominio personal",
      meaning: "Fuerza interior invencible, coraje del corazón, paciencia infinita, compasión profunda, autocontrol perfecto, resistencia espiritual",
      interpretation: "La Fuerza representa el poder más grande del universo: la fuerza del amor y la compasión. Te enseña que la verdadera fortaleza viene de la gentileza, la paciencia y el autocontrol. Es momento de enfrentar tus desafíos con coraje del corazón y dominar tus instintos más primitivos con amor.",
      advice: "Tu mayor fuerza reside en tu capacidad de amar y ser compasivo. Usa la gentileza para conquistar lo que la agresión no puede vencer."
    },
    reversed: {
      keywords: "Debilidad, falta de coraje, impaciencia, agresión, falta de autocontrol, cobardía, crueldad, dominio por fuerza",
      meaning: "Debilidad interior, falta de coraje, impaciencia destructiva, agresión descontrolada, falta de autocontrol, crueldad innecesaria",
      interpretation: "Invertida, La Fuerza indica que puedes estar actuando desde la debilidad, el miedo o la agresión en lugar de desde tu poder interior. También puede señalar falta de paciencia o autocontrol en situaciones que requieren gentileza y comprensión.",
      advice: "Reconecta con tu fuerza interior a través de la compasión hacia ti mismo. La verdadera fortaleza se construye desde el amor, no desde el miedo."
    }
  },
  {
    id: 10,
    name: "El Ermitaño",
    arcana: "mayor",
    number: 9,
    upright: {
      keywords: "Introspección, búsqueda interior, sabiduría, soledad, guía espiritual, iluminación, contemplación, autoconocimiento",
      meaning: "Introspección profunda, búsqueda interior sagrada, sabiduría ancestral, soledad constructiva, guía espiritual, iluminación personal",
      interpretation: "El Ermitaño te invita a emprender un viaje sagrado hacia tu interior para encontrar las respuestas que buscas. Es momento de retirarte del ruido del mundo y conectar con tu sabiduría más profunda. La soledad se convierte en tu maestra y la contemplación en tu herramienta de iluminación.",
      advice: "Busca las respuestas en tu interior a través de la meditación y la contemplación. Tu sabiduría interior es más valiosa que cualquier consejo externo."
    },
    reversed: {
      keywords: "Aislamiento, soledad no deseada, rechazo a la guía, terquedad, negación, evitar la introspección",
      meaning: "Aislamiento destructivo, soledad dolorosa, rechazo a la guía espiritual, terquedad extrema, negación de la verdad interior",
      interpretation: "Invertido, El Ermitaño puede indicar que te estás aislando de manera destructiva o que estás rechazando la guía espiritual que necesitas. También puede señalar resistencia a la introspección necesaria para tu crecimiento.",
      advice: "No confundas el aislamiento destructivo con la soledad constructiva. Busca el equilibrio entre la introspección y la conexión con otros."
    }
  },
  {
    id: 11,
    name: "La Rueda de la Fortuna",
    arcana: "mayor",
    number: 10,
    upright: {
      keywords: "Destino, ciclos, cambio, suerte, oportunidad, karma, giros del destino, evolución, transformación cíclica",
      meaning: "Destino en movimiento, ciclos naturales, cambios favorables, suerte divina, oportunidades kármicas, evolución espiritual",
      interpretation: "La Rueda de la Fortuna anuncia que los vientos del destino están cambiando a tu favor. Los ciclos naturales de la vida están trayendo nuevas oportunidades y transformaciones necesarias. Es momento de fluir con los cambios y confiar en que el universo está conspirando para tu bien supremo.",
      advice: "Fluye con los cambios naturales de la vida. Lo que parece ser suerte es en realidad el resultado de tu evolución espiritual y tus acciones pasadas."
    },
    reversed: {
      keywords: "Mala suerte, resistencia al cambio, ciclos negativos, estancamiento, falta de control, karma negativo",
      meaning: "Mala suerte temporal, resistencia destructiva al cambio, ciclos negativos, estancamiento espiritual, karma que necesita sanación",
      interpretation: "Invertida, La Rueda indica que puedes estar resistiendo cambios necesarios o experimentando un período de mala suerte que requiere paciencia y sabiduría. También puede señalar la necesidad de sanar patrones kármicos negativos.",
      advice: "Acepta que algunos ciclos deben completarse antes de que lleguen los nuevos. Usa este tiempo para sanar y prepararte para mejores oportunidades."
    }
  },
  {
    id: 12,
    name: "La Justicia",
    arcana: "mayor",
    number: 11,
    upright: {
      keywords: "Justicia, equilibrio, verdad, karma, responsabilidad, decisiones justas, integridad, causa y efecto, rectitud",
      meaning: "Justicia divina, equilibrio perfecto, verdad revelada, karma positivo, responsabilidad consciente, decisiones íntegras",
      interpretation: "La Justicia representa el equilibrio perfecto del universo y la ley de causa y efecto en acción. Es momento de tomar decisiones basadas en la verdad y la integridad, sabiendo que cada acción tiene consecuencias. La justicia divina está trabajando en tu favor cuando actúas desde la rectitud.",
      advice: "Actúa siempre desde la integridad y la verdad. El universo está registrando cada una de tus acciones y te recompensará en consecuencia."
    },
    reversed: {
      keywords: "Injusticia, desequilibrio, deshonestidad, karma negativo, decisiones incorrectas, falta de responsabilidad",
      meaning: "Injusticia temporal, desequilibrio en la vida, deshonestidad, karma negativo manifestándose, decisiones incorrectas",
      interpretation: "Invertida, La Justicia puede indicar que estás experimentando injusticias o que tus propias acciones pasadas están creando desequilibrios en tu vida. También puede señalar la necesidad de ser más honesto contigo mismo y con otros.",
      advice: "Examina tus acciones pasadas y presentes. La verdadera justicia comienza con la honestidad personal y la responsabilidad por tus decisiones."
    }
  },
  {
    id: 13,
    name: "El Colgado",
    arcana: "mayor",
    number: 12,
    upright: {
      keywords: "Sacrificio, perspectiva nueva, pausa, rendición, iluminación, paciencia, contemplación, liberación, cambio de visión",
      meaning: "Sacrificio consciente, perspectiva revolucionaria, pausa sagrada, rendición al proceso divino, iluminación a través de la espera",
      interpretation: "El Colgado te enseña el poder transformador de la pausa y la rendición consciente. Es momento de ver las situaciones desde una perspectiva completamente nueva y permitir que la sabiduría emerja a través de la paciencia. A veces, no hacer nada es la acción más poderosa.",
      advice: "Suelta el control y permite que las respuestas lleguen naturalmente. Tu perspectiva actual necesita una revolución completa para ver la verdad."
    },
    reversed: {
      keywords: "Resistencia, impaciencia, negación, estancamiento, sacrificio inútil, perspectiva limitada, terquedad",
      meaning: "Resistencia al cambio necesario, impaciencia destructiva, negación de la realidad, estancamiento por terquedad",
      interpretation: "Invertido, El Colgado indica que estás resistiendo una pausa o cambio de perspectiva que es esencial para tu crecimiento. También puede señalar impaciencia que está impidiendo que veas las soluciones que están frente a ti.",
      advice: "Deja de resistir y permite que el proceso natural de transformación ocurra. Tu impaciencia está bloqueando las bendiciones que están en camino."
    }
  },
  {
    id: 14,
    name: "La Muerte",
    arcana: "mayor",
    number: 13,
    upright: {
      keywords: "Transformación, final, renacimiento, cambio radical, liberación, renovación, evolución, metamorfosis, nuevo ciclo",
      meaning: "Transformación profunda, finales necesarios, renacimiento espiritual, cambio radical positivo, liberación total, renovación completa",
      interpretation: "La Muerte representa la transformación más profunda y necesaria de tu vida. No temas este cambio, pues es la puerta hacia tu renacimiento espiritual. Lo que está muriendo en tu vida ya no te sirve, y lo que está naciendo será infinitamente mejor. Es el final de un ciclo y el comienzo glorioso de otro.",
      advice: "Abraza la transformación con gratitud. Lo que está muriendo en tu vida está haciendo espacio para algo mucho más maravilloso."
    },
    reversed: {
      keywords: "Resistencia al cambio, estancamiento, miedo a la transformación, aferrarse al pasado, negación, muerte lenta",
      meaning: "Resistencia destructiva al cambio, estancamiento doloroso, miedo paralizante a la transformación, aferrarse al pasado",
      interpretation: "Invertida, La Muerte indica que estás resistiendo una transformación necesaria por miedo a lo desconocido. Esta resistencia está causando estancamiento y sufrimiento innecesario. Es momento de soltar lo que ya no te sirve.",
      advice: "Deja de aferrarte a lo que ya murió en tu vida. Tu resistencia al cambio está impidiendo tu renacimiento y evolución natural."
    }
  },
  {
    id: 15,
    name: "La Templanza",
    arcana: "mayor",
    number: 14,
    upright: {
      keywords: "Equilibrio, moderación, paciencia, armonía, sanación, integración, alquimia, flujo, adaptabilidad, síntesis",
      meaning: "Equilibrio perfecto, moderación sabia, paciencia infinita, armonía total, sanación profunda, integración de opuestos",
      interpretation: "La Templanza te enseña el arte divino del equilibrio y la moderación. Es momento de integrar todos los aspectos de tu ser y encontrar la armonía perfecta entre los opuestos. Esta carta representa la sanación a través de la paciencia y la alquimia espiritual que transforma todo en oro.",
      advice: "Busca el equilibrio en todas las áreas de tu vida. La moderación y la paciencia son tus herramientas más poderosas para la sanación y transformación."
    },
    reversed: {
      keywords: "Desequilibrio, excesos, impaciencia, falta de armonía, conflicto interno, desintegración, caos, extremos",
      meaning: "Desequilibrio severo, excesos destructivos, impaciencia extrema, falta de armonía interna, conflictos sin resolver",
      interpretation: "Invertida, La Templanza indica que has perdido el equilibrio y estás viviendo en extremos que te están causando sufrimiento. Es momento de encontrar el punto medio y sanar los conflictos internos que están creando caos en tu vida.",
      advice: "Regresa al centro de tu ser y busca la moderación en todas las cosas. Los extremos te están alejando de tu paz interior."
    }
  },
  {
    id: 16,
    name: "El Diablo",
    arcana: "mayor",
    number: 15,
    upright: {
      keywords: "Tentación, adicción, materialismo, esclavitud, ilusión, sombra, deseos, ataduras, dependencia, ego",
      meaning: "Tentaciones poderosas, adicciones que esclavizan, materialismo excesivo, ilusiones que ciegan, ataduras autoimpuestas",
      interpretation: "El Diablo representa las cadenas que tú mismo has creado a través de tus miedos, adicciones y apegos materiales. Es momento de reconocer qué te está esclavizando y recordar que tienes el poder de liberarte. Las cadenas son una ilusión; siempre has tenido la llave de tu libertad.",
      advice: "Reconoce tus adicciones y dependencias. El primer paso hacia la libertad es admitir qué te está esclavizando y tomar la decisión consciente de liberarte."
    },
    reversed: {
      keywords: "Liberación, ruptura de cadenas, superación, independencia, despertar, libertad, sanación de adicciones",
      meaning: "Liberación de ataduras, ruptura de cadenas limitantes, superación de adicciones, independencia recuperada, despertar espiritual",
      interpretation: "Invertido, El Diablo anuncia tu liberación de las cadenas que te han estado limitando. Estás despertando a tu verdadero poder y rompiendo patrones destructivos. Es un momento de gran liberación y recuperación de tu independencia espiritual.",
      advice: "Celebra tu liberación y mantente vigilante para no crear nuevas cadenas. Tu libertad es sagrada y debe ser protegida conscientemente."
    }
  },
  {
    id: 17,
    name: "La Torre",
    arcana: "mayor",
    number: 16,
    upright: {
      keywords: "Cambio súbito, revelación, destrucción, liberación, despertar, colapso, iluminación, revolución, caos creativo",
      meaning: "Cambio súbito y necesario, revelación impactante, destrucción de ilusiones, liberación forzada, despertar espiritual",
      interpretation: "La Torre representa el colapso necesario de estructuras falsas en tu vida. Aunque puede parecer destructivo, este cambio súbito es una bendición disfrazada que te libera de ilusiones y te despierta a una verdad más elevada. Es el rayo de iluminación que destruye lo falso para revelar lo auténtico.",
      advice: "No resistas el cambio súbito que está ocurriendo. Lo que se está derrumbando ya no te servía, y lo que emergerá será mucho más auténtico y sólido."
    },
    reversed: {
      keywords: "Resistencia al cambio, negación, evitar la verdad, colapso interno, destrucción gradual, miedo al cambio",
      meaning: "Resistencia al cambio necesario, negación de la verdad, evitar enfrentar la realidad, colapso interno gradual",
      interpretation: "Invertida, La Torre indica que estás resistiendo un cambio necesario o negando una verdad que necesita ser enfrentada. Esta resistencia está causando un colapso interno gradual que es más doloroso que el cambio súbito.",
      advice: "Deja de resistir la verdad que necesitas enfrentar. Es mejor permitir el cambio consciente que esperar a que las circunstancias te fuercen a cambiar."
    }
  },
  {
    id: 18,
    name: "La Estrella",
    arcana: "mayor",
    number: 17,
    upright: {
      keywords: "Esperanza, inspiración, sanación, renovación, fe, guía espiritual, optimismo, conexión cósmica, bendiciones",
      meaning: "Esperanza renovada, inspiración divina, sanación profunda, renovación espiritual, fe inquebrantable, guía celestial",
      interpretation: "La Estrella trae esperanza renovada y sanación después de la tormenta. Es momento de conectar con tu fe más profunda y permitir que la inspiración divina guíe tu camino. Las bendiciones están fluyendo hacia ti desde el cosmos, y tu futuro brilla con posibilidades infinitas.",
      advice: "Mantén tu fe y esperanza sin importar las circunstancias. El universo está conspirando para traerte bendiciones más allá de tu imaginación."
    },
    reversed: {
      keywords: "Desesperanza, falta de fe, desconexión espiritual, pesimismo, falta de inspiración, dudas, desaliento",
      meaning: "Desesperanza temporal, falta de fe, desconexión de la guía espiritual, pesimismo destructivo, falta de inspiración",
      interpretation: "Invertida, La Estrella indica que has perdido la esperanza y la conexión con tu guía espiritual. Es momento de renovar tu fe y recordar que incluso en la oscuridad más profunda, las estrellas siguen brillando.",
      advice: "Reconecta con tu fe y busca signos de esperanza a tu alrededor. La luz siempre regresa después de la oscuridad más profunda."
    }
  },
  {
    id: 19,
    name: "La Luna",
    arcana: "mayor",
    number: 18,
    upright: {
      keywords: "Ilusión, intuición, subconsciente, miedos, sueños, misterio, psiquismo, ciclos, emociones profundas",
      meaning: "Ilusiones que confunden, intuición profunda, subconsciente activo, miedos ancestrales, sueños reveladores, misterios ocultos",
      interpretation: "La Luna te invita a navegar por las aguas profundas de tu subconsciente y enfrentar las ilusiones que han estado nublando tu visión. Es momento de confiar en tu intuición para distinguir entre la realidad y la fantasía, y de sanar los miedos ancestrales que emergen en la oscuridad.",
      advice: "Confía en tu intuición para navegar por la confusión actual. No todo es lo que parece, pero tu sabiduría interior te guiará hacia la verdad."
    },
    reversed: {
      keywords: "Claridad, superación de ilusiones, liberación de miedos, verdad revelada, despertar, realidad, lucidez",
      meaning: "Claridad mental recuperada, superación de ilusiones, liberación de miedos irracionales, verdad finalmente revelada",
      interpretation: "Invertida, La Luna indica que estás emergiendo de un período de confusión y las ilusiones se están disipando. La verdad está siendo revelada y tus miedos están perdiendo poder sobre ti. Es un momento de gran claridad y despertar.",
      advice: "Celebra la claridad que estás ganando. Usa esta nueva perspectiva para tomar decisiones más sabias y auténticas."
    }
  },
  {
    id: 20,
    name: "El Sol",
    arcana: "mayor",
    number: 19,
    upright: {
      keywords: "Alegría, éxito, vitalidad, optimismo, claridad, iluminación, felicidad, energía, positividad, celebración",
      meaning: "Alegría pura, éxito radiante, vitalidad desbordante, optimismo contagioso, claridad total, iluminación completa",
      interpretation: "El Sol trae alegría pura, éxito radiante y vitalidad desbordante a tu vida. Es momento de celebrar tus logros y disfrutar de la claridad y positividad que te rodea. Tu luz interior está brillando con toda su fuerza, iluminando el camino para ti y para otros.",
      advice: "Celebra tus éxitos y comparte tu alegría con otros. Tu luz interior tiene el poder de iluminar y sanar todo lo que toca."
    },
    reversed: {
      keywords: "Tristeza temporal, falta de energía, pesimismo, nubosidad, retrasos en el éxito, falta de claridad",
      meaning: "Tristeza temporal, falta de energía vital, pesimismo pasajero, nubosidad emocional, retrasos en el éxito esperado",
      interpretation: "Invertido, El Sol indica que estás pasando por un período temporal de tristeza o falta de energía. Las nubes están bloqueando tu luz natural, pero esto es solo temporal. Tu alegría y vitalidad regresarán pronto.",
      advice: "Ten paciencia contigo mismo durante este período nublado. Tu luz natural es demasiado poderosa para permanecer oculta por mucho tiempo."
    }
  },
  {
    id: 21,
    name: "El Juicio",
    arcana: "mayor",
    number: 20,
    upright: {
      keywords: "Renacimiento, despertar, llamada superior, juicio final, resurrección, evaluación, segunda oportunidad, redención",
      meaning: "Renacimiento espiritual, despertar de conciencia, llamada superior del alma, juicio divino favorable, resurrección personal",
      interpretation: "El Juicio anuncia tu renacimiento espiritual y el despertar a tu llamada superior. Es momento de evaluar tu vida pasada con compasión y prepararte para una nueva fase de existencia más elevada. El universo te está dando una segunda oportunidad para vivir tu propósito más auténtico.",
      advice: "Responde a la llamada de tu alma y abraza tu renacimiento espiritual. Es momento de dejar atrás el pasado y emerger como tu yo más auténtico."
    },
    reversed: {
      keywords: "Negación del llamado, resistencia al despertar, juicio severo, falta de perdón, miedo al cambio",
      meaning: "Negación del llamado superior, resistencia al despertar espiritual, juicio severo hacia ti mismo, falta de perdón",
      interpretation: "Invertido, El Juicio indica que estás resistiendo tu llamada superior o siendo demasiado severo en tu autoevaluación. Es momento de perdonarte y permitir que tu renacimiento espiritual ocurra naturalmente.",
      advice: "Perdónate por el pasado y permite que tu alma responda a su llamada superior. La resistencia solo retrasa tu evolución inevitable."
    }
  },
  {
    id: 22,
    name: "El Mundo",
    arcana: "mayor",
    number: 21,
    upright: {
      keywords: "Completitud, logro, realización, éxito total, culminación, perfección, integración, maestría, plenitud",
      meaning: "Completitud absoluta, logro total, realización plena, éxito en todos los niveles, culminación perfecta, maestría alcanzada",
      interpretation: "El Mundo representa la culminación perfecta de tu viaje y la realización total de tu potencial. Has alcanzado un nivel de maestría y completitud que te permite disfrutar de los frutos de tu evolución. Es momento de celebrar todo lo que has logrado y prepararte para nuevos ciclos de crecimiento.",
      advice: "Celebra tu completitud y maestría alcanzada. Has llegado al final de un ciclo importante, y ahora puedes comenzar una nueva aventura desde un lugar de sabiduría y poder."
    },
    reversed: {
      keywords: "Incompletitud, falta de logro, retrasos, imperfección, falta de integración, metas no alcanzadas",
      meaning: "Incompletitud frustrante, falta de logro esperado, retrasos significativos, imperfección que molesta, falta de integración",
      interpretation: "Invertido, El Mundo indica que sientes que algo está incompleto o que no has alcanzado el nivel de éxito que esperabas. Es momento de reevaluar tus expectativas y reconocer el progreso que sí has hecho.",
      advice: "Reconoce que la perfección es un proceso, no un destino. Celebra tu progreso actual mientras continúas trabajando hacia tus objetivos más elevados."
    }
  }
];
