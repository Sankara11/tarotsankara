
export const swords = [
  {
    id: 37,
    name: "As de Espadas",
    arcana: "menor",
    suit: "espadas",
    number: 1,
    upright: {
      keywords: "Claridad mental, nueva perspectiva, comunicación, verdad, justicia, poder intelectual, corte limpio, revelación",
      meaning: "Claridad mental absoluta, nueva perspectiva revolucionaria, comunicación poderosa, verdad revelada, justicia divina, poder intelectual puro",
      interpretation: "El As de Espadas trae claridad mental absoluta y nuevas ideas revolucionarias. Es momento de cortar con lo que no sirve y comunicar tu verdad con honestidad total. Tu mente está afilada como una espada y puede cortar a través de cualquier confusión o engaño.",
      advice: "Usa tu claridad mental para tomar decisiones importantes y comunica tu verdad sin miedo. Tu poder intelectual está en su punto más alto."
    },
    reversed: {
      keywords: "Confusión, falta de claridad, comunicación bloqueada, verdades ocultas, injusticia, poder mal usado, caos mental",
      meaning: "Confusión mental severa, falta total de claridad, comunicación completamente bloqueada, verdades peligrosamente ocultas, injusticia flagrante",
      interpretation: "Invertido, indica confusión mental severa o dificultades significativas para expresar ideas claramente. También puede señalar que la verdad está siendo ocultada o distorsionada.",
      advice: "Busca claridad a través de la meditación y la reflexión. No tomes decisiones importantes hasta que tu mente esté clara y enfocada."
    }
  },
  {
    id: 38,
    name: "Dos de Espadas",
    arcana: "menor",
    suit: "espadas",
    number: 2,
    upright: {
      keywords: "Decisión difícil, equilibrio mental, estancamiento, dilema, indecisión, bloqueo mental, opciones iguales, impasse",
      meaning: "Decisión extremadamente difícil, equilibrio mental precario, estancamiento total, dilema imposible, indecisión paralizante",
      interpretation: "El Dos de Espadas representa un momento de indecisión donde todas las opciones parecen igualmente válidas o problemáticas. Tu mente está en equilibrio precario y necesitas encontrar una forma de romper el estancamiento para avanzar.",
      advice: "Tómate el tiempo necesario para evaluar todas las opciones, pero no permitas que la indecisión te paralice indefinidamente. Confía en tu intuición para romper el empate."
    },
    reversed: {
      keywords: "Decisión tomada, claridad recuperada, fin del estancamiento, resolución, liberación mental, acción decidida",
      meaning: "Decisión finalmente tomada, claridad completamente recuperada, fin total del estancamiento, resolución perfecta, liberación mental completa",
      interpretation: "Invertido, indica que has roto el estancamiento y tomado una decisión importante. La claridad mental ha regresado y puedes avanzar con confianza hacia tus objetivos.",
      advice: "Celebra tu capacidad de tomar decisiones difíciles y mantén la confianza en tus elecciones. Tu claridad mental te guiará hacia el éxito."
    }
  },
  {
    id: 39,
    name: "Tres de Espadas",
    arcana: "menor",
    suit: "espadas",
    number: 3,
    upright: {
      keywords: "Dolor del corazón, traición, separación, duelo, tristeza profunda, pérdida emocional, corazón roto, sufrimiento",
      meaning: "Dolor del corazón devastador, traición profunda, separación dolorosa, duelo abrumador, tristeza infinita, pérdida emocional severa",
      interpretation: "El Tres de Espadas representa dolor emocional profundo, traición o pérdida que ha herido tu corazón. Aunque el sufrimiento es intenso, es importante recordar que el dolor también puede ser un maestro que te enseña sobre la compasión y la resistencia.",
      advice: "Permite que el dolor siga su curso natural sin resistirlo. El sufrimiento, aunque difícil, puede enseñarte lecciones valiosas sobre la compasión y la fortaleza."
    },
    reversed: {
      keywords: "Sanación del corazón, perdón, recuperación emocional, liberación del dolor, reconciliación, paz interior",
      meaning: "Sanación completa del corazón, perdón liberador, recuperación emocional total, liberación completa del dolor, reconciliación perfecta",
      interpretation: "Invertido, indica que estás sanando de heridas emocionales profundas y encontrando la paz interior. El perdón está trayendo liberación y tu corazón se está abriendo nuevamente al amor.",
      advice: "Celebra tu proceso de sanación y mantén el corazón abierto al amor. Has demostrado una fortaleza emocional extraordinaria al sanar estas heridas."
    }
  },
  {
    id: 40,
    name: "Cuatro de Espadas",
    arcana: "menor",
    suit: "espadas",
    number: 4,
    upright: {
      keywords: "Descanso, meditación, pausa, recuperación, contemplación, paz mental, retiro, sanación mental, quietud",
      meaning: "Descanso profundo, meditación sanadora, pausa necesaria, recuperación mental completa, contemplación sagrada, paz mental absoluta",
      interpretation: "El Cuatro de Espadas indica la necesidad de descanso mental y recuperación después de un período de estrés o conflicto. Es momento de hacer una pausa, meditar y permitir que tu mente se sane en la quietud y la contemplación.",
      advice: "Tómate el descanso mental que necesitas sin sentirte culpable. Tu mente necesita tiempo para procesar y sanarse antes de enfrentar nuevos desafíos."
    },
    reversed: {
      keywords: "Inquietud mental, insomnio, estrés, agitación, falta de descanso, mente hiperactiva, ansiedad, agotamiento mental",
      meaning: "Inquietud mental severa, insomnio crónico, estrés abrumador, agitación constante, falta total de descanso, mente completamente hiperactiva",
      interpretation: "Invertido, indica que tu mente está demasiado agitada para descansar adecuadamente. El estrés y la ansiedad están impidiendo la recuperación mental que necesitas urgentemente.",
      advice: "Busca ayuda profesional para manejar el estrés y la ansiedad. Tu salud mental es prioritaria y merece atención especializada."
    }
  },
  {
    id: 41,
    name: "Cinco de Espadas",
    arcana: "menor",
    suit: "espadas",
    number: 5,
    upright: {
      keywords: "Conflicto, derrota, humillación, traición, victoria vacía, pérdida de honor, batalla perdida, deshonor",
      meaning: "Conflicto destructivo, derrota humillante, traición dolorosa, victoria completamente vacía, pérdida total de honor, batalla perdida",
      interpretation: "El Cinco de Espadas representa conflicto, derrota o una victoria que se siente vacía porque se logró a costa de otros. Es momento de evaluar si vale la pena ganar cuando el costo es tan alto en términos de relaciones y honor personal.",
      advice: "Evalúa si tus victorias valen el costo en relaciones y honor personal. A veces es mejor retirarse con dignidad que ganar a cualquier precio."
    },
    reversed: {
      keywords: "Reconciliación, perdón, fin del conflicto, humildad, lecciones aprendidas, paz restaurada, sanación de relaciones",
      meaning: "Reconciliación genuina, perdón mutuo, fin completo del conflicto, humildad verdadera, lecciones profundamente aprendidas, paz totalmente restaurada",
      interpretation: "Invertido, indica que los conflictos se están resolviendo y la reconciliación es posible. Has aprendido lecciones valiosas sobre el costo del conflicto y estás listo para sanar las relaciones dañadas.",
      advice: "Abraza la oportunidad de reconciliación y perdón. Las lecciones aprendidas del conflicto te han hecho más sabio y compasivo."
    }
  },
  {
    id: 42,
    name: "Seis de Espadas",
    arcana: "menor",
    suit: "espadas",
    number: 6,
    upright: {
      keywords: "Transición, viaje, mudanza, progreso gradual, aguas más calmadas, sanación lenta, esperanza renovada, cambio positivo",
      meaning: "Transición necesaria, viaje transformador, mudanza liberadora, progreso gradual pero constante, aguas definitivamente más calmadas",
      interpretation: "El Seis de Espadas indica que estás en transición hacia aguas más calmadas después de un período turbulento. El progreso es gradual pero constante, y cada paso te aleja del conflicto hacia la paz y la sanación.",
      advice: "Ten paciencia con el proceso de transición. Cada paso te está llevando hacia aguas más calmadas y un futuro más pacífico."
    },
    reversed: {
      keywords: "Resistencia al cambio, estancamiento, regreso al pasado, progreso bloqueado, aguas turbulentas, retroceso",
      meaning: "Resistencia total al cambio, estancamiento frustrante, regreso destructivo al pasado, progreso completamente bloqueado, aguas extremadamente turbulentas",
      interpretation: "Invertido, indica resistencia al cambio necesario o un retroceso hacia patrones problemáticos del pasado. El progreso está siendo bloqueado por el miedo o la resistencia al crecimiento.",
      advice: "Deja de resistir los cambios necesarios para tu crecimiento. El miedo al futuro te está manteniendo atrapado en patrones que ya no te sirven."
    }
  },
  {
    id: 43,
    name: "Siete de Espadas",
    arcana: "menor",
    suit: "espadas",
    number: 7,
    upright: {
      keywords: "Engaño, robo, estrategia, astucia, evasión, deshonestidad, traición, secretos, manipulación, escape",
      meaning: "Engaño sutil, robo emocional, estrategia manipulativa, astucia deshonesta, evasión de responsabilidades, traición calculada",
      interpretation: "El Siete de Espadas advierte sobre engaño, deshonestidad o traición en tu entorno. Alguien puede estar actuando de manera deshonesta o tú mismo puedes estar evadiendo responsabilidades importantes. Es momento de enfrentar la verdad.",
      advice: "Mantente alerta ante el engaño y la deshonestidad, tanto en otros como en ti mismo. La honestidad total es la única base sólida para relaciones auténticas."
    },
    reversed: {
      keywords: "Honestidad restaurada, confesión, responsabilidad, verdad revelada, fin del engaño, integridad recuperada",
      meaning: "Honestidad completamente restaurada, confesión liberadora, responsabilidad total asumida, verdad finalmente revelada, integridad recuperada",
      interpretation: "Invertido, indica que la verdad está siendo revelada y la honestidad está siendo restaurada. Los engaños están siendo expuestos y la integridad está regresando a las relaciones.",
      advice: "Celebra el retorno de la honestidad y la integridad. Usa esta oportunidad para construir relaciones más auténticas y transparentes."
    }
  },
  {
    id: 44,
    name: "Ocho de Espadas",
    arcana: "menor",
    suit: "espadas",
    number: 8,
    upright: {
      keywords: "Restricción, limitación, prisión mental, victimización, impotencia, atrapado, ceguera, paralización, autoengaño",
      meaning: "Restricción severa, limitación autoimpuesta, prisión mental total, victimización constante, impotencia aprendida, ceguera voluntaria",
      interpretation: "El Ocho de Espadas indica que te sientes atrapado por circunstancias o limitaciones que en gran parte son autoimpuestas. Aunque te sientes impotente, en realidad tienes más poder del que crees para cambiar tu situación.",
      advice: "Reconoce que muchas de tus limitaciones son autoimpuestas. Tienes más poder para cambiar tu situación del que crees; solo necesitas encontrar el coraje para actuar."
    },
    reversed: {
      keywords: "Liberación, empoderamiento, libertad recuperada, claridad mental, escape, autoconfianza restaurada, acción decidida",
      meaning: "Liberación completa, empoderamiento total, libertad completamente recuperada, claridad mental absoluta, escape exitoso, autoconfianza restaurada",
      interpretation: "Invertido, indica que estás liberándote de las limitaciones que te tenían atrapado. Tu poder personal está regresando y puedes ver claramente las opciones que tienes disponibles.",
      advice: "Celebra tu liberación y usa tu poder recuperado sabiamente. Has demostrado que puedes superar cualquier limitación cuando te lo propones."
    }
  },
  {
    id: 45,
    name: "Nueve de Espadas",
    arcana: "menor",
    suit: "espadas",
    number: 9,
    upright: {
      keywords: "Ansiedad, pesadillas, preocupación, insomnio, culpa, remordimiento, tormento mental, miedo, desesperación",
      meaning: "Ansiedad abrumadora, pesadillas constantes, preocupación extrema, insomnio crónico, culpa devastadora, remordimiento profundo, tormento mental",
      interpretation: "El Nueve de Espadas representa ansiedad extrema, preocupaciones que te mantienen despierto por la noche y tormento mental. Es importante recordar que muchos de estos miedos son peores en tu mente que en la realidad.",
      advice: "Busca ayuda profesional para manejar la ansiedad y los pensamientos tormentosos. No tienes que sufrir en silencio; hay recursos disponibles para ayudarte."
    },
    reversed: {
      keywords: "Alivio de la ansiedad, esperanza renovada, sanación mental, paz interior, liberación de culpa, perdón propio",
      meaning: "Alivio completo de la ansiedad, esperanza totalmente renovada, sanación mental profunda, paz interior absoluta, liberación total de culpa",
      interpretation: "Invertido, indica que estás encontrando alivio de la ansiedad y el tormento mental. La esperanza está regresando y estás sanando de heridas psicológicas profundas.",
      advice: "Celebra tu progreso en la sanación mental y mantén las prácticas que te están ayudando. Tu fortaleza mental está creciendo cada día."
    }
  },
  {
    id: 46,
    name: "Diez de Espadas",
    arcana: "menor",
    suit: "espadas",
    number: 10,
    upright: {
      keywords: "Final doloroso, traición total, colapso, derrota completa, victimización, dolor extremo, fin de ciclo, rock bottom",
      meaning: "Final extremadamente doloroso, traición absolutamente total, colapso completo, derrota devastadora, victimización severa, dolor indescriptible",
      interpretation: "El Diez de Espadas representa el final más doloroso posible de una situación, pero también marca el punto más bajo desde el cual solo puedes subir. Aunque el dolor es intenso, este final es necesario para tu renacimiento.",
      advice: "Aunque el dolor es intenso, recuerda que has tocado fondo y desde aquí solo puedes subir. Este final doloroso es el preludio de tu renacimiento."
    },
    reversed: {
      keywords: "Recuperación, renacimiento, sanación gradual, esperanza renovada, resiliencia, superación, nuevo amanecer",
      meaning: "Recuperación milagrosa, renacimiento espiritual, sanación gradual pero constante, esperanza completamente renovada, resiliencia extraordinaria",
      interpretation: "Invertido, indica que estás recuperándote de la derrota más dolorosa y renaciendo como el ave fénix. Tu resiliencia es extraordinaria y estás demostrando una fortaleza que no sabías que tenías.",
      advice: "Celebra tu increíble capacidad de recuperación y renacimiento. Has demostrado una fortaleza extraordinaria que te servirá para toda la vida."
    }
  },
  {
    id: 47,
    name: "Sota de Espadas",
    arcana: "menor",
    suit: "espadas",
    number: 11,
    upright: {
      keywords: "Curiosidad intelectual, vigilancia, espionaje, comunicación directa, mente aguda, investigación, alerta mental",
      meaning: "Curiosidad intelectual intensa, vigilancia constante, comunicación extremadamente directa, mente increíblemente aguda, investigación profunda",
      interpretation: "La Sota de Espadas representa una mente joven, curiosa y alerta que está siempre buscando información y verdades ocultas. Es momento de usar tu inteligencia y curiosidad para investigar y descubrir lo que necesitas saber.",
      advice: "Usa tu curiosidad natural y mente aguda para investigar y descubrir la verdad. Tu capacidad de observación es una herramienta valiosa."
    },
    reversed: {
      keywords: "Chismorreo, espionaje malicioso, comunicación destructiva, mentiras, manipulación de información, traición de confianza",
      meaning: "Chismorreo destructivo, espionaje maliciosamente motivado, comunicación completamente destructiva, mentiras constantes, manipulación total de información",
      interpretation: "Invertida, indica que la curiosidad se ha vuelto destructiva o que alguien está usando información de manera maliciosa. También puede señalar comunicación deshonesta o chismorreo dañino.",
      advice: "Usa tu inteligencia de manera constructiva, no para dañar a otros. La información es poder, pero debe ser usada responsablemente."
    }
  },
  {
    id: 48,
    name: "Caballero de Espadas",
    arcana: "menor",
    suit: "espadas",
    number: 12,
    upright: {
      keywords: "Acción rápida, impulsividad, comunicación directa, valentía, determinación, cambio súbito, energía mental intensa",
      meaning: "Acción extremadamente rápida, impulsividad total, comunicación brutalmente directa, valentía temeraria, determinación férrea, cambio súbito",
      interpretation: "El Caballero de Espadas representa acción rápida y decisiva, comunicación directa y cambios súbitos. Su energía es intensa y puede ser tanto constructiva como destructiva, dependiendo de cómo se canalice.",
      advice: "Canaliza tu energía mental intensa de manera constructiva. La acción rápida puede ser poderosa, pero asegúrate de que esté bien dirigida."
    },
    reversed: {
      keywords: "Imprudencia, agresión verbal, falta de planificación, destrucción, comunicación hiriente, violencia verbal",
      meaning: "Imprudencia extrema, agresión verbal severa, falta total de planificación, destrucción innecesaria, comunicación profundamente hiriente",
      interpretation: "Invertido, indica que la energía mental se está expresando de manera destructiva a través de imprudencia, agresión verbal o falta de consideración por otros.",
      advice: "Controla tu impulsividad y piensa antes de hablar o actuar. Tu energía mental puede ser destructiva si no la canalizas adecuadamente."
    }
  },
  {
    id: 49,
    name: "Reina de Espadas",
    arcana: "menor",
    suit: "espadas",
    number: 13,
    upright: {
      keywords: "Claridad mental, independencia, comunicación directa, sabiduría, objetividad, liderazgo intelectual, discernimiento",
      meaning: "Claridad mental absoluta, independencia total, comunicación perfectamente directa, sabiduría profunda, objetividad completa, liderazgo intelectual natural",
      interpretation: "La Reina de Espadas representa la maestría intelectual y la capacidad de comunicarse con claridad y sabiduría. Ella lidera con su mente brillante y mantiene la objetividad incluso en situaciones emocionales intensas.",
      advice: "Usa tu claridad mental y sabiduría para liderar y comunicarte efectivamente. Tu objetividad es un regalo valioso en situaciones complejas."
    },
    reversed: {
      keywords: "Frialdad emocional, crueldad, comunicación hiriente, amargura, crítica destructiva, aislamiento, dureza excesiva",
      meaning: "Frialdad emocional extrema, crueldad innecesaria, comunicación profundamente hiriente, amargura tóxica, crítica completamente destructiva",
      interpretation: "Invertida, indica que la claridad mental se ha vuelto frialdad emocional o que estás usando tu inteligencia para herir a otros. La amargura puede estar nublando tu juicio.",
      advice: "Equilibra tu claridad mental con compasión emocional. La inteligencia sin corazón puede ser cruel y destructiva."
    }
  },
  {
    id: 50,
    name: "Rey de Espadas",
    arcana: "menor",
    suit: "espadas",
    number: 14,
    upright: {
      keywords: "Autoridad intelectual, justicia, liderazgo mental, disciplina, control, poder de decisión, sabiduría madura, orden",
      meaning: "Autoridad intelectual absoluta, justicia perfecta, liderazgo mental natural, disciplina férrea, control total, poder de decisión supremo",
      interpretation: "El Rey de Espadas representa la autoridad intelectual madura y el poder de tomar decisiones justas basadas en la lógica y la sabiduría. Él mantiene el orden a través de la disciplina mental y la comunicación clara.",
      advice: "Ejerce tu autoridad intelectual con justicia y sabiduría. Tu capacidad de tomar decisiones claras es un don que debe ser usado responsablemente."
    },
    reversed: {
      keywords: "Tiranía intelectual, abuso de poder, decisiones injustas, frialdad, control excesivo, autoritarismo, crueldad mental",
      meaning: "Tiranía intelectual severa, abuso total de poder, decisiones completamente injustas, frialdad extrema, control absolutamente excesivo",
      interpretation: "Invertido, indica que el poder intelectual se está usando de manera tiránica o injusta. También puede señalar frialdad emocional que está dañando las relaciones.",
      advice: "Usa tu poder intelectual para servir a la justicia, no para dominar a otros. El verdadero liderazgo inspira, no intimida."
    }
  }
];
