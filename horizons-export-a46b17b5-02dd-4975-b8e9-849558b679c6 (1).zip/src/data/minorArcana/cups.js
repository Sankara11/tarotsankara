
export const cups = [
  {
    id: 23,
    name: "As de Copas",
    arcana: "menor",
    suit: "copas",
    number: 1,
    upright: {
      keywords: "Nuevo amor, compasión, creatividad, espiritualidad, intuición, emociones puras, bendiciones emocionales, apertura del corazón",
      meaning: "Nuevo amor divino, compasión infinita, creatividad desbordante, espiritualidad profunda, intuición clara, emociones puras",
      interpretation: "El As de Copas anuncia nuevos comienzos emocionales extraordinarios. Es momento de abrir completamente tu corazón a nuevas experiencias de amor, creatividad y conexión espiritual. El universo está derramando bendiciones emocionales en tu vida, y tu capacidad de amar se está expandiendo infinitamente.",
      advice: "Abre tu corazón completamente a las nuevas experiencias emocionales que están llegando. Tu capacidad de amar y crear está en su punto más elevado."
    },
    reversed: {
      keywords: "Bloqueo emocional, amor no correspondido, creatividad reprimida, vacío espiritual, emociones bloqueadas",
      meaning: "Bloqueo emocional severo, amor no correspondido doloroso, creatividad completamente reprimida, vacío espiritual profundo",
      interpretation: "Invertido, indica dificultades significativas para expresar emociones o bloqueos severos en el flujo creativo y amoroso. Tu corazón puede estar cerrado por heridas pasadas que necesitan sanación urgente.",
      advice: "Sana las heridas de tu corazón que están bloqueando el flujo natural del amor y la creatividad. Busca ayuda profesional si es necesario."
    }
  },
  {
    id: 24,
    name: "Dos de Copas",
    arcana: "menor",
    suit: "copas",
    number: 2,
    upright: {
      keywords: "Unión, sociedad, conexión mutua, armonía, amor recíproco, equilibrio emocional, partnership, compromiso",
      meaning: "Unión sagrada, sociedad perfecta, conexión mutua profunda, armonía emocional, amor completamente recíproco",
      interpretation: "El Dos de Copas representa conexiones profundas y mutuamente beneficiosas que nutren el alma. Es momento de fortalecer vínculos importantes en tu vida y celebrar las relaciones que te aportan equilibrio y crecimiento mutuo. El amor verdadero está floreciendo.",
      advice: "Invierte tiempo y energía en las relaciones que te nutren mutuamente. El amor verdadero se construye con reciprocidad y respeto mutuo."
    },
    reversed: {
      keywords: "Desequilibrio en relaciones, falta de armonía, separación, amor no correspondido, conflictos emocionales",
      meaning: "Desequilibrio severo en relaciones, falta total de armonía, separación dolorosa, amor completamente no correspondido",
      interpretation: "Invertido, sugiere tensiones significativas en las relaciones o la necesidad urgente de trabajar en el equilibrio emocional. Puede indicar que estás dando mucho más de lo que recibes en tus relaciones.",
      advice: "Evalúa el equilibrio en tus relaciones importantes. Es momento de establecer límites saludables y buscar reciprocidad genuina."
    }
  },
  {
    id: 25,
    name: "Tres de Copas",
    arcana: "menor",
    suit: "copas",
    number: 3,
    upright: {
      keywords: "Celebración, amistad, comunidad, alegría compartida, festividad, apoyo social, creatividad grupal, hermandad",
      meaning: "Celebración jubilosa, amistad verdadera, comunidad amorosa, alegría compartida, festividad del alma, apoyo incondicional",
      interpretation: "El Tres de Copas trae celebración, amistad verdadera y el gozo de pertenecer a una comunidad amorosa. Es momento de celebrar tus logros con las personas que realmente te aman y apoyan. La alegría compartida multiplica la felicidad.",
      advice: "Celebra tus éxitos con las personas que genuinamente se alegran por ti. La verdadera amistad es uno de los tesoros más valiosos de la vida."
    },
    reversed: {
      keywords: "Aislamiento social, conflictos en grupos, envidia, celebraciones vacías, falta de apoyo, soledad",
      meaning: "Aislamiento social doloroso, conflictos destructivos en grupos, envidia tóxica, celebraciones completamente vacías",
      interpretation: "Invertido, indica problemas en tu círculo social o sentimientos de aislamiento cuando más necesitas apoyo. Puede señalar envidias o conflictos que están dañando tus relaciones grupales.",
      advice: "Evalúa la calidad de tu círculo social. Es mejor estar solo que rodeado de personas que no te apoyan genuinamente."
    }
  },
  {
    id: 26,
    name: "Cuatro de Copas",
    arcana: "menor",
    suit: "copas",
    number: 4,
    upright: {
      keywords: "Apatía, descontento, oportunidades perdidas, introspección, aburrimiento, estancamiento emocional, contemplación",
      meaning: "Apatía emocional, descontento profundo, oportunidades constantemente perdidas, introspección excesiva, aburrimiento existencial",
      interpretation: "El Cuatro de Copas indica un período de apatía emocional y descontento con las opciones disponibles. Estás tan enfocado en lo que falta que no ves las oportunidades que se presentan. Es momento de salir de la introspección excesiva y actuar.",
      advice: "Sal de tu zona de confort emocional y considera nuevas posibilidades. Las oportunidades están frente a ti, pero necesitas abrir los ojos para verlas."
    },
    reversed: {
      keywords: "Renovación emocional, nuevas oportunidades, motivación recuperada, acción, despertar, interés renovado",
      meaning: "Renovación emocional completa, nuevas oportunidades emocionantes, motivación completamente recuperada, despertar del alma",
      interpretation: "Invertido, indica que estás saliendo de un período de apatía y recuperando tu motivación emocional. Nuevas oportunidades están capturando tu atención y tu interés por la vida está renaciendo.",
      advice: "Aprovecha esta renovación emocional para explorar nuevas posibilidades. Tu motivación recuperada es un regalo que debes usar sabiamente."
    }
  },
  {
    id: 27,
    name: "Cinco de Copas",
    arcana: "menor",
    suit: "copas",
    number: 5,
    upright: {
      keywords: "Pérdida, duelo, decepción, tristeza, lamento, dolor emocional, pérdida de esperanza, melancolía",
      meaning: "Pérdida significativa, duelo profundo, decepción devastadora, tristeza abrumadora, lamento constante, dolor emocional intenso",
      interpretation: "El Cinco de Copas representa pérdida y duelo que necesitan ser procesados completamente. Aunque el dolor es real y válido, es importante recordar que no todo está perdido. Aún hay copas en pie que representan esperanza y posibilidades futuras.",
      advice: "Permite que el duelo siga su curso natural, pero no te quedes atrapado en el dolor. Aún hay bendiciones en tu vida que merecen tu atención."
    },
    reversed: {
      keywords: "Recuperación, aceptación, perdón, sanación emocional, esperanza renovada, superación del duelo",
      meaning: "Recuperación emocional, aceptación completa, perdón liberador, sanación emocional profunda, esperanza completamente renovada",
      interpretation: "Invertido, indica que estás sanando de pérdidas pasadas y recuperando tu estabilidad emocional. El perdón y la aceptación están trayendo paz a tu corazón, y la esperanza está renaciendo en tu vida.",
      advice: "Celebra tu proceso de sanación y mantén el corazón abierto a nuevas bendiciones. Has demostrado una fortaleza emocional extraordinaria."
    }
  },
  {
    id: 28,
    name: "Seis de Copas",
    arcana: "menor",
    suit: "copas",
    number: 6,
    upright: {
      keywords: "Nostalgia, recuerdos, inocencia, pasado, niñez, simplicidad, generosidad, regalos del pasado, dulzura",
      meaning: "Nostalgia dulce, recuerdos hermosos, inocencia recuperada, conexión con el pasado, simplicidad del corazón, generosidad pura",
      interpretation: "El Seis de Copas te invita a reconectar con la inocencia y simplicidad de tu niñez. Los recuerdos dulces y las lecciones del pasado están trayendo sanación y perspectiva a tu presente. Es momento de honrar tu historia y extraer sabiduría de ella.",
      advice: "Honra tu pasado y extrae las lecciones valiosas que te ha enseñado. La inocencia y simplicidad pueden ser tus guías hacia la felicidad auténtica."
    },
    reversed: {
      keywords: "Vivir en el pasado, nostalgia tóxica, resistencia al crecimiento, inmadurez, idealización del pasado",
      meaning: "Vivir completamente en el pasado, nostalgia tóxica y paralizante, resistencia total al crecimiento, inmadurez emocional",
      interpretation: "Invertido, indica que estás demasiado apegado al pasado y esto está impidiendo tu crecimiento presente. La nostalgia se ha vuelto tóxica y te mantiene atrapado en patrones infantiles.",
      advice: "Es momento de soltar el pasado y abrazar tu crecimiento presente. Los recuerdos son hermosos, pero no deben impedir tu evolución."
    }
  },
  {
    id: 29,
    name: "Siete de Copas",
    arcana: "menor",
    suit: "copas",
    number: 7,
    upright: {
      keywords: "Ilusiones, fantasías, opciones múltiples, confusión, sueños, wishful thinking, dispersión, elecciones difíciles",
      meaning: "Ilusiones seductoras, fantasías escapistas, opciones abrumadoramente múltiples, confusión total, sueños irreales",
      interpretation: "El Siete de Copas indica que estás perdido en fantasías e ilusiones que te impiden tomar decisiones claras. Hay tantas opciones que te sientes abrumado y confundido. Es momento de distinguir entre sueños realistas y fantasías escapistas.",
      advice: "Aterriza tus sueños en la realidad y enfócate en opciones concretas y alcanzables. No todas las fantasías merecen tu tiempo y energía."
    },
    reversed: {
      keywords: "Claridad, realismo, decisiones claras, enfoque, determinación, ilusiones disipadas, objetivos concretos",
      meaning: "Claridad mental total, realismo práctico, decisiones completamente claras, enfoque láser, determinación inquebrantable",
      interpretation: "Invertido, indica que las ilusiones se están disipando y estás ganando claridad sobre lo que realmente quieres. Tu enfoque se está agudizando y puedes tomar decisiones más realistas y efectivas.",
      advice: "Aprovecha esta claridad mental para tomar decisiones importantes. Tu capacidad de discernimiento está en su punto más alto."
    }
  },
  {
    id: 30,
    name: "Ocho de Copas",
    arcana: "menor",
    suit: "copas",
    number: 8,
    upright: {
      keywords: "Abandono, búsqueda espiritual, dejar atrás, crecimiento personal, viaje interior, insatisfacción, búsqueda de significado",
      meaning: "Abandono necesario, búsqueda espiritual profunda, dejar atrás lo conocido, crecimiento personal radical, viaje interior sagrado",
      interpretation: "El Ocho de Copas representa el momento en que debes dejar atrás lo que ya no te nutre para buscar un significado más profundo. Aunque es difícil abandonar lo familiar, tu alma te está llamando hacia un crecimiento que requiere este sacrificio.",
      advice: "Ten el coraje de dejar atrás lo que ya no te sirve, incluso si es cómodo. Tu alma está llamándote hacia un crecimiento más profundo."
    },
    reversed: {
      keywords: "Miedo al cambio, aferrarse al pasado, evitar el crecimiento, conformismo, resistencia al llamado interior",
      meaning: "Miedo paralizante al cambio, aferrarse desesperadamente al pasado, evitar completamente el crecimiento, conformismo tóxico",
      interpretation: "Invertido, indica que estás resistiendo un llamado interior hacia el crecimiento por miedo a dejar tu zona de confort. Esta resistencia está causando estancamiento y frustración profunda.",
      advice: "No permitas que el miedo te mantenga atrapado en situaciones que ya no te nutren. Tu crecimiento espiritual es más importante que la comodidad."
    }
  },
  {
    id: 31,
    name: "Nueve de Copas",
    arcana: "menor",
    suit: "copas",
    number: 9,
    upright: {
      keywords: "Satisfacción, realización de deseos, contentamiento, abundancia emocional, gratitud, plenitud, éxito emocional",
      meaning: "Satisfacción completa, realización total de deseos, contentamiento profundo, abundancia emocional desbordante, gratitud infinita",
      interpretation: "El Nueve de Copas es la carta de la satisfacción emocional y la realización de deseos. Has alcanzado un nivel de contentamiento y abundancia emocional que te permite disfrutar plenamente de la vida. Es momento de celebrar y agradecer todo lo que has logrado.",
      advice: "Disfruta plenamente de este período de satisfacción y abundancia. Tu gratitud atraerá aún más bendiciones a tu vida."
    },
    reversed: {
      keywords: "Insatisfacción, vacío interior, materialismo superficial, falta de gratitud, deseos no cumplidos, superficialidad",
      meaning: "Insatisfacción profunda, vacío interior abrumador, materialismo completamente superficial, falta total de gratitud",
      interpretation: "Invertido, indica que a pesar de tener mucho, sientes un vacío interior que no puedes llenar con posesiones materiales. Es momento de buscar satisfacción en aspectos más profundos de la vida.",
      advice: "Busca la satisfacción en conexiones auténticas y crecimiento espiritual, no en posesiones materiales. El vacío interior solo se llena con amor y propósito."
    }
  },
  {
    id: 32,
    name: "Diez de Copas",
    arcana: "menor",
    suit: "copas",
    number: 10,
    upright: {
      keywords: "Felicidad familiar, armonía, realización emocional, amor incondicional, bendiciones, hogar feliz, plenitud emocional",
      meaning: "Felicidad familiar perfecta, armonía total, realización emocional completa, amor absolutamente incondicional, bendiciones abundantes",
      interpretation: "El Diez de Copas representa la culminación de la felicidad emocional y familiar. Has creado o encontrado un entorno de amor incondicional y armonía que nutre tu alma. Es la realización de tus sueños más profundos sobre el amor y la familia.",
      advice: "Celebra y protege la armonía familiar que has creado. Este tipo de amor incondicional es uno de los tesoros más valiosos de la vida."
    },
    reversed: {
      keywords: "Conflictos familiares, desarmonía, disfunción, valores rotos, separación, falta de apoyo familiar",
      meaning: "Conflictos familiares severos, desarmonía total, disfunción destructiva, valores completamente rotos, separación dolorosa",
      interpretation: "Invertido, indica problemas significativos en el ámbito familiar o la falta del apoyo emocional que necesitas. Puede señalar la necesidad de sanar relaciones familiares o crear tu propia familia elegida.",
      advice: "Trabaja en sanar las relaciones familiares importantes o busca crear tu propia familia elegida. Todos merecemos amor incondicional y apoyo."
    }
  },
  {
    id: 33,
    name: "Sota de Copas",
    arcana: "menor",
    suit: "copas",
    number: 11,
    upright: {
      keywords: "Mensajero emocional, intuición joven, creatividad emergente, sensibilidad, romance joven, nuevas emociones, inspiración artística",
      meaning: "Mensajero de emociones nuevas, intuición joven y pura, creatividad emergente, sensibilidad extrema, romance floreciente",
      interpretation: "La Sota de Copas trae mensajes emocionales nuevos y el despertar de tu sensibilidad artística. Representa la parte de ti que está abierta a nuevas experiencias emocionales y creativas. Es momento de explorar tu lado más sensible y receptivo.",
      advice: "Mantén tu corazón abierto a nuevas experiencias emocionales y creativas. Tu sensibilidad es un don que debe ser honrado y desarrollado."
    },
    reversed: {
      keywords: "Inmadurez emocional, sensibilidad excesiva, creatividad bloqueada, emociones reprimidas, falta de inspiración",
      meaning: "Inmadurez emocional severa, sensibilidad completamente excesiva, creatividad totalmente bloqueada, emociones profundamente reprimidas",
      interpretation: "Invertida, indica inmadurez emocional o una sensibilidad tan extrema que te impide funcionar efectivamente. También puede señalar bloqueos creativos que necesitan atención.",
      advice: "Desarrolla madurez emocional mientras mantienes tu sensibilidad natural. Busca ayuda para desbloquear tu creatividad si es necesario."
    }
  },
  {
    id: 34,
    name: "Caballero de Copas",
    arcana: "menor",
    suit: "copas",
    number: 12,
    upright: {
      keywords: "Romance, carisma, invitación emocional, propuestas, encanto, seducción, ofertas de amor, galantería, idealismo romántico",
      meaning: "Romance apasionado, carisma irresistible, invitaciones emocionales, propuestas de amor, encanto natural, seducción elegante",
      interpretation: "El Caballero de Copas trae romance, propuestas emocionales y invitaciones a nuevas aventuras del corazón. Representa la energía del cortejo y la búsqueda apasionada del amor ideal. Es momento de seguir tu corazón con valentía.",
      advice: "Sigue tu corazón con valentía, pero mantén los pies en la tierra. El romance verdadero requiere tanto pasión como realismo."
    },
    reversed: {
      keywords: "Promesas vacías, manipulación emocional, infidelidad, desilusión romántica, seducción falsa, engaño sentimental",
      meaning: "Promesas completamente vacías, manipulación emocional severa, infidelidad dolorosa, desilusión romántica total, seducción completamente falsa",
      interpretation: "Invertido, advierte sobre promesas vacías o manipulación emocional en el ámbito romántico. Alguien puede estar usando tu sensibilidad en tu contra o no siendo honesto sobre sus intenciones.",
      advice: "Mantente alerta ante las promesas vacías y la manipulación emocional. Confía en tu intuición cuando algo no se sienta genuino."
    }
  },
  {
    id: 35,
    name: "Reina de Copas",
    arcana: "menor",
    suit: "copas",
    number: 13,
    upright: {
      keywords: "Intuición maternal, compasión, empatía, sanación emocional, sabiduría del corazón, nutrición, cuidado, amor incondicional",
      meaning: "Intuición maternal profunda, compasión infinita, empatía total, sanación emocional poderosa, sabiduría del corazón antigua",
      interpretation: "La Reina de Copas representa la maestría emocional y la sabiduría del corazón. Ella sana con su presencia y nutre con su amor incondicional. Es momento de confiar en tu intuición y usar tu sensibilidad como una herramienta de sanación.",
      advice: "Confía en tu intuición y usa tu sensibilidad natural para sanar y nutrir a otros. Tu compasión es una fuerza poderosa de transformación."
    },
    reversed: {
      keywords: "Codependencia, manipulación emocional, víctima, drama, inestabilidad emocional, sobreprotección, mártir",
      meaning: "Codependencia severa, manipulación emocional tóxica, victimización constante, drama destructivo, inestabilidad emocional extrema",
      interpretation: "Invertida, indica codependencia o el uso de la sensibilidad para manipular a otros. También puede señalar inestabilidad emocional que necesita atención profesional.",
      advice: "Establece límites emocionales saludables y busca ayuda si estás atrapada en patrones codependientes. Tu sensibilidad debe ser una fortaleza, no una debilidad."
    }
  },
  {
    id: 36,
    name: "Rey de Copas",
    arcana: "menor",
    suit: "copas",
    number: 14,
    upright: {
      keywords: "Maestría emocional, equilibrio, compasión sabia, liderazgo emocional, estabilidad, madurez emocional, consejero sabio",
      meaning: "Maestría emocional completa, equilibrio perfecto, compasión infinitamente sabia, liderazgo emocional natural, estabilidad absoluta",
      interpretation: "El Rey de Copas representa la maestría emocional y el equilibrio perfecto entre el corazón y la mente. Él lidera con compasión sabia y mantiene la estabilidad emocional incluso en las tormentas más intensas. Es momento de asumir tu poder emocional maduro.",
      advice: "Lidera con compasión sabia y mantén tu equilibrio emocional sin importar las circunstancias. Tu estabilidad emocional es un regalo para todos."
    },
    reversed: {
      keywords: "Represión emocional, frialdad, manipulación sutil, control emocional, tiranía emocional, falta de compasión",
      meaning: "Represión emocional severa, frialdad extrema, manipulación emocionalmente sutil, control emocional tóxico, tiranía emocional",
      interpretation: "Invertido, indica represión emocional o el uso del control emocional para manipular a otros. También puede señalar frialdad emocional que está dañando las relaciones.",
      advice: "Reconecta con tu corazón y permite que las emociones fluyan naturalmente. El control emocional excesivo es tan dañino como la falta de control."
    }
  }
];
