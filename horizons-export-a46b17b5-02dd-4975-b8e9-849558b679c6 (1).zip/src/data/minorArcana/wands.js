
export const wands = [
  {
    id: 51,
    name: "As de Bastos",
    arcana: "menor",
    suit: "bastos",
    number: 1,
    upright: {
      keywords: "Inspiración, nuevos proyectos, crecimiento, potencial, energía creativa, oportunidades, iniciativa, pasión, motivación",
      meaning: "Inspiración divina, nuevos proyectos emocionantes, crecimiento exponencial, potencial ilimitado, energía creativa desbordante, oportunidades doradas",
      interpretation: "El As de Bastos anuncia nuevas oportunidades creativas y profesionales llenas de potencial. Es momento de actuar sobre tus ideas más inspiradoras y canalizar tu energía creativa hacia proyectos que realmente te apasionen. El universo está apoyando tus iniciativas.",
      advice: "Actúa sobre tus ideas más inspiradoras mientras la energía creativa está en su punto más alto. Este es el momento perfecto para comenzar nuevos proyectos."
    },
    reversed: {
      keywords: "Falta de energía, proyectos retrasados, falta de dirección, bloqueo creativo, oportunidades perdidas, desmotivación",
      meaning: "Falta severa de energía, proyectos significativamente retrasados, falta total de dirección, bloqueo creativo completo, oportunidades constantemente perdidas",
      interpretation: "Invertido, sugiere que necesitas reenfocar tu energía o que tus proyectos necesitan más planificación y estructura. También puede indicar bloqueos creativos que requieren atención.",
      advice: "Reconecta con tu pasión y propósito para recuperar la motivación. A veces es necesario hacer una pausa para reevaluar la dirección de tus proyectos."
    }
  },
  {
    id: 52,
    name: "Dos de Bastos",
    arcana: "menor",
    suit: "bastos",
    number: 2,
    upright: {
      keywords: "Planificación, visión futura, decisiones, control personal, ambición, estrategia, expansión, liderazgo, dominio",
      meaning: "Planificación estratégica, visión futura clara, decisiones importantes, control personal total, ambición saludable, expansión planificada",
      interpretation: "El Dos de Bastos representa el momento de planificación estratégica y toma de decisiones importantes sobre tu futuro. Tienes el control y la visión necesarios para expandir tus horizontes y alcanzar tus ambiciones más elevadas.",
      advice: "Usa tu visión clara del futuro para tomar decisiones estratégicas importantes. Tu capacidad de planificación te llevará hacia el éxito que buscas."
    },
    reversed: {
      keywords: "Falta de planificación, indecisión, falta de control, visión limitada, miedo al cambio, conformismo, estancamiento",
      meaning: "Falta total de planificación, indecisión paralizante, falta completa de control, visión extremadamente limitada, miedo paralizante al cambio",
      interpretation: "Invertido, indica falta de planificación o miedo a tomar las decisiones necesarias para tu crecimiento. También puede señalar que te estás conformando con menos de lo que mereces.",
      advice: "Desarrolla una visión clara de tu futuro y crea un plan estratégico para alcanzarla. No permitas que el miedo te mantenga en tu zona de confort."
    }
  },
  {
    id: 53,
    name: "Tres de Bastos",
    arcana: "menor",
    suit: "bastos",
    number: 3,
    upright: {
      keywords: "Expansión, exploración, comercio, viajes, visión amplia, progreso, crecimiento, oportunidades internacionales, liderazgo",
      meaning: "Expansión exitosa, exploración fructífera, comercio próspero, viajes transformadores, visión amplia del mundo, progreso constante",
      interpretation: "El Tres de Bastos indica que tus planes están dando frutos y es momento de expandir tus horizontes. Las oportunidades de crecimiento, viajes o comercio están presentándose, y tu visión amplia te permitirá aprovecharlas al máximo.",
      advice: "Aprovecha las oportunidades de expansión que se presentan. Tu visión amplia y capacidad de liderazgo te llevarán hacia nuevos territorios de éxito."
    },
    reversed: {
      keywords: "Retrasos en expansión, oportunidades perdidas, falta de visión, problemas de comunicación, planes frustrados",
      meaning: "Retrasos significativos en expansión, oportunidades constantemente perdidas, falta total de visión, problemas severos de comunicación",
      interpretation: "Invertido, indica retrasos en tus planes de expansión o dificultades para aprovechar las oportunidades que se presentan. También puede señalar problemas de comunicación que están obstaculizando tu progreso.",
      advice: "Reevalúa tus estrategias de expansión y mejora tu comunicación. Los retrasos actuales pueden ser oportunidades para perfeccionar tus planes."
    }
  },
  {
    id: 54,
    name: "Cuatro de Bastos",
    arcana: "menor",
    suit: "bastos",
    number: 4,
    upright: {
      keywords: "Celebración, logros, estabilidad, hogar, comunidad, armonía, festividad, éxito, fundaciones sólidas, alegría",
      meaning: "Celebración merecida, logros significativos, estabilidad completa, hogar armonioso, comunidad amorosa, festividad del alma",
      interpretation: "El Cuatro de Bastos trae celebración y reconocimiento por tus logros. Has establecido fundaciones sólidas y es momento de disfrutar de la estabilidad y armonía que has creado. Tu hogar y comunidad te brindan apoyo y alegría.",
      advice: "Celebra tus logros y disfruta de la estabilidad que has creado. Has trabajado duro para llegar hasta aquí y mereces reconocer tu éxito."
    },
    reversed: {
      keywords: "Falta de armonía, inestabilidad en el hogar, conflictos familiares, celebraciones canceladas, falta de apoyo",
      meaning: "Falta total de armonía, inestabilidad severa en el hogar, conflictos familiares destructivos, celebraciones constantemente canceladas",
      interpretation: "Invertido, indica problemas en el hogar o la comunidad que están afectando tu estabilidad emocional. También puede señalar que no estás recibiendo el reconocimiento que mereces por tus logros.",
      advice: "Trabaja en sanar los conflictos familiares o comunitarios que están afectando tu paz. Busca crear armonía en tu entorno más cercano."
    }
  },
  {
    id: 55,
    name: "Cinco de Bastos",
    arcana: "menor",
    suit: "bastos",
    number: 5,
    upright: {
      keywords: "Competencia, conflicto, desafíos, rivalidad, lucha, tensión, desacuerdo, caos creativo, diversidad de opiniones",
      meaning: "Competencia intensa, conflicto constructivo, desafíos estimulantes, rivalidad saludable, lucha necesaria, tensión creativa",
      interpretation: "El Cinco de Bastos representa competencia y conflicto que, aunque desafiantes, pueden ser constructivos y estimulantes. Es momento de defender tus ideas y demostrar tu valía en un entorno competitivo.",
      advice: "Abraza la competencia saludable como una oportunidad de crecimiento. Los desafíos actuales te están haciendo más fuerte y más hábil."
    },
    reversed: {
      keywords: "Evitar conflictos, falta de competencia, conformismo, armonía forzada, supresión de diferencias, estancamiento",
      meaning: "Evitar completamente conflictos, falta total de competencia, conformismo extremo, armonía artificialmente forzada, supresión total de diferencias",
      interpretation: "Invertido, indica que estás evitando conflictos necesarios o que la falta de competencia está causando estancamiento. También puede señalar conformismo que está limitando tu crecimiento.",
      advice: "No evites todos los conflictos; algunos son necesarios para el crecimiento. La competencia saludable puede motivarte a alcanzar tu mejor versión."
    }
  },
  {
    id: 56,
    name: "Seis de Bastos",
    arcana: "menor",
    suit: "bastos",
    number: 6,
    upright: {
      keywords: "Victoria, reconocimiento, éxito público, liderazgo, triunfo, admiración, logros reconocidos, confianza, orgullo",
      meaning: "Victoria merecida, reconocimiento público, éxito ampliamente celebrado, liderazgo natural, triunfo completo, admiración genuina",
      interpretation: "El Seis de Bastos trae victoria y reconocimiento público por tus esfuerzos. Has demostrado liderazgo y tus logros están siendo celebrados por otros. Es momento de disfrutar del éxito y la admiración que has ganado.",
      advice: "Disfruta del reconocimiento que has ganado, pero mantén la humildad. Tu éxito actual es la base para logros aún mayores en el futuro."
    },
    reversed: {
      keywords: "Falta de reconocimiento, fracaso público, ego herido, arrogancia, caída del pedestal, humillación, pérdida de estatus",
      meaning: "Falta total de reconocimiento, fracaso públicamente humillante, ego severamente herido, arrogancia destructiva, caída dramática del pedestal",
      interpretation: "Invertido, indica falta de reconocimiento por tus esfuerzos o una caída pública que ha herido tu ego. También puede señalar que la arrogancia está saboteando tu éxito.",
      advice: "Mantén la humildad incluso en el éxito y aprende de cualquier fracaso público. El verdadero liderazgo se demuestra en cómo manejas tanto el éxito como el fracaso."
    }
  },
  {
    id: 57,
    name: "Siete de Bastos",
    arcana: "menor",
    suit: "bastos",
    number: 7,
    upright: {
      keywords: "Defensa, perseverancia, resistencia, competencia feroz, mantener posición, valentía, determinación, lucha, desafíos",
      meaning: "Defensa valiente, perseverancia inquebrantable, resistencia heroica, competencia extremadamente feroz, determinación férrea",
      interpretation: "El Siete de Bastos indica que estás defendiendo tu posición contra desafíos y competencia feroz. Aunque la lucha es intensa, tu perseverancia y determinación te permitirán mantener tu terreno y salir victorioso.",
      advice: "Mantén tu posición con valentía y determinación. Los desafíos actuales están probando tu fortaleza, pero tienes lo necesario para superarlos."
    },
    reversed: {
      keywords: "Rendirse, falta de resistencia, abrumado por desafíos, pérdida de posición, agotamiento, derrota, falta de confianza",
      meaning: "Rendirse prematuramente, falta total de resistencia, completamente abrumado por desafíos, pérdida significativa de posición, agotamiento extremo",
      interpretation: "Invertido, indica que te sientes abrumado por los desafíos y estás considerando rendirte. También puede señalar que has perdido confianza en tu capacidad de defender tu posición.",
      advice: "Recupera tu confianza y encuentra nuevas fuentes de energía para continuar la lucha. No te rindas cuando estás tan cerca de la victoria."
    }
  },
  {
    id: 58,
    name: "Ocho de Bastos",
    arcana: "menor",
    suit: "bastos",
    number: 8,
    upright: {
      keywords: "Velocidad, movimiento rápido, progreso acelerado, comunicación rápida, viajes, noticias, acción inmediata, momentum",
      meaning: "Velocidad extraordinaria, movimiento extremadamente rápido, progreso dramáticamente acelerado, comunicación instantánea, momentum imparable",
      interpretation: "El Ocho de Bastos indica que las cosas se están moviendo muy rápidamente en tu vida. El progreso se está acelerando, las comunicaciones son rápidas y eficientes, y el momentum está construyéndose hacia tus objetivos.",
      advice: "Aprovecha este período de movimiento rápido y progreso acelerado. Mantente alerta y listo para actuar cuando lleguen las oportunidades."
    },
    reversed: {
      keywords: "Retrasos, frustración, comunicación lenta, obstáculos, impaciencia, falta de progreso, estancamiento, bloqueos",
      meaning: "Retrasos significativos, frustración extrema, comunicación extremadamente lenta, obstáculos constantes, impaciencia destructiva",
      interpretation: "Invertido, indica retrasos frustrantes y obstáculos que están ralentizando tu progreso. También puede señalar impaciencia que está creando más problemas de los que resuelve.",
      advice: "Ten paciencia con los retrasos actuales y usa este tiempo para perfeccionar tus planes. Los obstáculos temporales no pueden detener tu progreso permanentemente."
    }
  },
  {
    id: 59,
    name: "Nueve de Bastos",
    arcana: "menor",
    suit: "bastos",
    number: 9,
    upright: {
      keywords: "Resistencia, perseverancia, último esfuerzo, agotamiento, vigilancia, protección, fortaleza, determinación final",
      meaning: "Resistencia heroica, perseverancia inquebrantable, último esfuerzo supremo, vigilancia constante, protección férrea, fortaleza extraordinaria",
      interpretation: "El Nueve de Bastos indica que estás en la recta final de una lucha larga y desafiante. Aunque estás agotado, tu resistencia y determinación te llevarán hasta la línea de meta. Mantén la vigilancia y no bajes la guardia ahora.",
      advice: "Mantén tu resistencia y vigilancia hasta el final. Estás más cerca de la victoria de lo que crees, no te rindas en la recta final."
    },
    reversed: {
      keywords: "Agotamiento extremo, rendirse, paranoia, falta de resistencia, colapso, abandono, pérdida de vigilancia",
      meaning: "Agotamiento absolutamente extremo, rendirse completamente, paranoia destructiva, falta total de resistencia, colapso completo",
      interpretation: "Invertido, indica agotamiento extremo que está afectando tu capacidad de continuar. También puede señalar paranoia o la tentación de rendirse cuando estás tan cerca del éxito.",
      advice: "Busca apoyo y descansa si es necesario, pero no abandones tus objetivos. Estás más cerca del éxito de lo que crees."
    }
  },
  {
    id: 60,
    name: "Diez de Bastos",
    arcana: "menor",
    suit: "bastos",
    number: 10,
    upright: {
      keywords: "Sobrecarga, responsabilidad excesiva, agotamiento, carga pesada, sacrificio, perseverancia, meta cercana, esfuerzo final",
      meaning: "Sobrecarga abrumadora, responsabilidad extremadamente excesiva, agotamiento total, carga increíblemente pesada, sacrificio supremo",
      interpretation: "El Diez de Bastos indica que estás cargando con demasiadas responsabilidades y te sientes abrumado. Aunque la carga es pesada, estás muy cerca de alcanzar tu meta. Es momento de evaluar qué puedes delegar o soltar.",
      advice: "Evalúa qué responsabilidades puedes delegar o soltar. No tienes que cargar con todo tú solo; busca apoyo y comparte la carga."
    },
    reversed: {
      keywords: "Liberación de cargas, delegación, alivio, soltar responsabilidades, recuperación, apoyo recibido, peso aliviado",
      meaning: "Liberación completa de cargas, delegación exitosa, alivio total, soltar completamente responsabilidades innecesarias, recuperación plena",
      interpretation: "Invertido, indica que estás encontrando formas de aliviar la carga y delegar responsabilidades. El apoyo está llegando y puedes respirar más fácilmente.",
      advice: "Celebra el alivio de las cargas pesadas y mantén un equilibrio saludable entre responsabilidad y bienestar personal."
    }
  },
  {
    id: 61,
    name: "Sota de Bastos",
    arcana: "menor",
    suit: "bastos",
    number: 11,
    upright: {
      keywords: "Entusiasmo, aventura, exploración, energía juvenil, curiosidad, espontaneidad, nuevas experiencias, pasión emergente",
      meaning: "Entusiasmo desbordante, aventura emocionante, exploración valiente, energía juvenil contagiosa, curiosidad infinita, espontaneidad pura",
      interpretation: "La Sota de Bastos trae entusiasmo juvenil y el deseo de explorar nuevas aventuras. Es momento de abrazar tu curiosidad natural y permitir que tu pasión emergente te guíe hacia experiencias emocionantes y crecimiento personal.",
      advice: "Abraza tu entusiasmo natural y permite que te guíe hacia nuevas aventuras. Tu energía juvenil es contagiosa y puede inspirar a otros."
    },
    reversed: {
      keywords: "Impulsividad destructiva, falta de dirección, energía dispersa, impaciencia, proyectos abandonados, falta de compromiso",
      meaning: "Impulsividad completamente destructiva, falta total de dirección, energía completamente dispersa, impaciencia extrema, proyectos constantemente abandonados",
      interpretation: "Invertida, indica que el entusiasmo se ha vuelto impulsividad destructiva o que la energía está siendo dispersada en demasiadas direcciones sin lograr resultados concretos.",
      advice: "Canaliza tu entusiasmo hacia objetivos específicos y desarrolla más paciencia y compromiso con tus proyectos."
    }
  },
  {
    id: 62,
    name: "Caballero de Bastos",
    arcana: "menor",
    suit: "bastos",
    number: 12,
    upright: {
      keywords: "Acción impulsiva, aventura, pasión, energía ardiente, cambio súbito, valentía, impetuosidad, viajes, conquista",
      meaning: "Acción extremadamente impulsiva, aventura apasionada, pasión ardiente, energía completamente ardiente, cambio súbito y dramático",
      interpretation: "El Caballero de Bastos representa acción impulsiva y pasión ardiente que puede llevar tanto al éxito como al desastre. Su energía es intensa y transformadora, pero necesita ser canalizada sabiamente para evitar consecuencias destructivas.",
      advice: "Canaliza tu pasión y energía ardiente hacia objetivos constructivos. Tu impulso natural puede ser poderoso si lo diriges sabiamente."
    },
    reversed: {
      keywords: "Imprudencia, agresión, falta de autocontrol, destrucción, violencia, arrebatos, energía mal dirigida, caos",
      meaning: "Imprudencia extrema, agresión destructiva, falta total de autocontrol, destrucción innecesaria, violencia descontrolada, energía completamente mal dirigida",
      interpretation: "Invertido, indica que la energía pasional se está expresando de manera destructiva a través de imprudencia, agresión o falta de autocontrol que está causando caos y destrucción.",
      advice: "Controla tu impulsividad y aprende a canalizar tu energía de manera constructiva. La pasión sin dirección puede ser muy destructiva."
    }
  },
  {
    id: 63,
    name: "Reina de Bastos",
    arcana: "menor",
    suit: "bastos",
    number: 13,
    upright: {
      keywords: "Confianza, determinación, liderazgo carismático, independencia, energía solar, creatividad madura, inspiración, calidez",
      meaning: "Confianza absoluta, determinación inquebrantable, liderazgo naturalmente carismático, independencia total, energía solar radiante, creatividad completamente madura",
      interpretation: "La Reina de Bastos representa confianza madura y liderazgo carismático que inspira a otros. Ella combina creatividad con determinación práctica y lidera con calidez y energía solar que nutre y motiva a todos a su alrededor.",
      advice: "Lidera con confianza y carisma, inspirando a otros con tu energía solar. Tu combinación de creatividad y determinación es una fuerza poderosa."
    },
    reversed: {
      keywords: "Inseguridad, celos, manipulación, control excesivo, temperamento, egoísmo, energía bloqueada, falta de inspiración",
      meaning: "Inseguridad profunda, celos destructivos, manipulación sutil, control absolutamente excesivo, temperamento explosivo, egoísmo extremo",
      interpretation: "Invertida, indica que la confianza se ha vuelto arrogancia o que los celos y la inseguridad están saboteando tu liderazgo natural. También puede señalar uso de manipulación en lugar de inspiración genuina.",
      advice: "Trabaja en tu autoestima y seguridad personal sin caer en la arrogancia. Lidera con inspiración genuina, no con manipulación o control."
    }
  },
  {
    id: 64,
    name: "Rey de Bastos",
    arcana: "menor",
    suit: "bastos",
    number: 14,
    upright: {
      keywords: "Liderazgo visionario, emprendimiento, carisma maduro, autoridad natural, inspiración, éxito empresarial, poder creativo",
      meaning: "Liderazgo absolutamente visionario, emprendimiento exitoso, carisma completamente maduro, autoridad completamente natural, inspiración profunda",
      interpretation: "El Rey de Bastos representa liderazgo visionario maduro y éxito empresarial basado en creatividad e inspiración. Él combina pasión con sabiduría práctica y tiene la autoridad natural para liderar grandes proyectos hacia el éxito.",
      advice: "Usa tu liderazgo visionario para inspirar y liderar grandes proyectos hacia el éxito. Tu combinación de pasión y sabiduría práctica es una fuerza imparable."
    },
    reversed: {
      keywords: "Tiranía, abuso de poder, arrogancia, impulsividad destructiva, liderazgo tóxico, egoísmo, dominación, control excesivo",
      meaning: "Tiranía destructiva, abuso total de poder, arrogancia extrema, impulsividad completamente destructiva, liderazgo absolutamente tóxico",
      interpretation: "Invertido, indica que el liderazgo se ha vuelto tiránico o que el poder está siendo abusado. También puede señalar arrogancia e impulsividad que están saboteando el éxito y dañando las relaciones.",
      advice: "Usa tu poder para servir a otros, no para dominarlos. El verdadero liderazgo eleva a todos, no solo al líder."
    }
  }
];
