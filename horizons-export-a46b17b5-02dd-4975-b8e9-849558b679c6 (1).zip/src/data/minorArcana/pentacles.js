
export const pentacles = [
  {
    id: 65,
    name: "As de Oros",
    arcana: "menor",
    suit: "oros",
    number: 1,
    upright: {
      keywords: "Nueva oportunidad financiera, manifestación, prosperidad, abundancia material, semilla de riqueza, potencial económico, estabilidad",
      meaning: "Nueva oportunidad financiera dorada, manifestación material exitosa, prosperidad abundante, riqueza potencial ilimitada, estabilidad económica sólida",
      interpretation: "El As de Oros representa nuevas oportunidades materiales y financieras que tienen el potencial de crear prosperidad duradera. Es momento de sembrar las semillas de la abundancia futura y manifestar tus objetivos materiales con determinación y sabiduría práctica.",
      advice: "Aprovecha las nuevas oportunidades financieras que se presentan. Este es el momento perfecto para sembrar las semillas de tu prosperidad futura."
    },
    reversed: {
      keywords: "Oportunidad perdida, falta de planificación, avaricia, materialismo excesivo, inestabilidad financiera, desperdicio de recursos",
      meaning: "Oportunidad financiera completamente perdida, falta total de planificación, avaricia destructiva, materialismo absolutamente excesivo, inestabilidad financiera severa",
      interpretation: "Invertido, advierte sobre oportunidades financieras desperdiciadas o la necesidad de ser más práctico y planificado con los recursos. También puede indicar que el materialismo excesivo está bloqueando la verdadera abundancia.",
      advice: "Sé más práctico con tus recursos y no dejes pasar oportunidades por falta de planificación. La verdadera abundancia requiere sabiduría, no solo ambición."
    }
  },
  {
    id: 66,
    name: "Dos de Oros",
    arcana: "menor",
    suit: "oros",
    number: 2,
    upright: {
      keywords: "Equilibrio financiero, malabarismo, adaptabilidad, flexibilidad, múltiples proyectos, gestión de recursos, cambio, versatilidad",
      meaning: "Equilibrio financiero perfecto, malabarismo exitoso, adaptabilidad total, flexibilidad extrema, gestión experta de múltiples proyectos",
      interpretation: "El Dos de Oros indica que estás manejando múltiples responsabilidades financieras o proyectos con habilidad y flexibilidad. Aunque puede ser desafiante mantener el equilibrio, tu adaptabilidad te permite navegar los cambios con gracia.",
      advice: "Mantén la flexibilidad mientras manejas múltiples responsabilidades. Tu capacidad de adaptación es tu mayor fortaleza en tiempos de cambio."
    },
    reversed: {
      keywords: "Desequilibrio financiero, sobrecarga, falta de organización, caos, pérdida de control, mala gestión, estrés financiero",
      meaning: "Desequilibrio financiero severo, sobrecarga abrumadora, falta total de organización, caos financiero, pérdida completa de control",
      interpretation: "Invertido, indica que estás abrumado por demasiadas responsabilidades financieras y perdiendo el control de tu situación económica. Es momento de reorganizar y priorizar.",
      advice: "Reorganiza tus finanzas y prioriza las responsabilidades más importantes. No puedes manejar todo al mismo tiempo sin un plan claro."
    }
  },
  {
    id: 67,
    name: "Tres de Oros",
    arcana: "menor",
    suit: "oros",
    number: 3,
    upright: {
      keywords: "Trabajo en equipo, colaboración, habilidad, maestría, reconocimiento profesional, construcción, planificación, competencia",
      meaning: "Trabajo en equipo excepcional, colaboración perfecta, habilidad reconocida, maestría profesional, reconocimiento merecido, construcción exitosa",
      interpretation: "El Tres de Oros representa trabajo en equipo exitoso y reconocimiento por tu habilidad y competencia profesional. Es momento de colaborar con otros para construir algo duradero y significativo que beneficie a todos los involucrados.",
      advice: "Colabora con otros para crear algo duradero y significativo. Tu habilidad y competencia están siendo reconocidas y valoradas."
    },
    reversed: {
      keywords: "Falta de cooperación, conflictos laborales, trabajo de mala calidad, falta de reconocimiento, desorganización, competencia destructiva",
      meaning: "Falta total de cooperación, conflictos laborales severos, trabajo de calidad extremadamente mala, falta completa de reconocimiento",
      interpretation: "Invertido, indica problemas de colaboración o falta de reconocimiento por tu trabajo. También puede señalar que la calidad de tu trabajo o el de tu equipo no está cumpliendo con los estándares necesarios.",
      advice: "Mejora la comunicación y colaboración en tu equipo. Asegúrate de que la calidad de tu trabajo esté a la altura de tus ambiciones."
    }
  },
  {
    id: 68,
    name: "Cuatro de Oros",
    arcana: "menor",
    suit: "oros",
    number: 4,
    upright: {
      keywords: "Seguridad financiera, ahorro, conservación, estabilidad, control, posesividad, avaricia, miedo a la pérdida, materialismo",
      meaning: "Seguridad financiera sólida, ahorro disciplinado, conservación sabia, estabilidad económica, control total de recursos",
      interpretation: "El Cuatro de Oros representa seguridad financiera y estabilidad, pero también advierte sobre el peligro de volverse demasiado posesivo o avaro. Es importante encontrar el equilibrio entre la seguridad y la generosidad.",
      advice: "Mantén tu seguridad financiera, pero no permitas que el miedo a la pérdida te vuelva tacaño o te impida disfrutar de la vida."
    },
    reversed: {
      keywords: "Generosidad, liberación financiera, desprendimiento, inversión sabia, flujo de abundancia, superación de avaricia",
      meaning: "Generosidad genuina, liberación financiera completa, desprendimiento sabio, inversión extremadamente sabia, flujo abundante de riqueza",
      interpretation: "Invertido, indica que estás liberándote de patrones avaros y aprendiendo a ser más generoso con tus recursos. También puede señalar inversiones sabias que están creando flujo de abundancia.",
      advice: "Celebra tu capacidad de ser generoso mientras mantienes la sabiduría financiera. El flujo de abundancia se crea dando y recibiendo en equilibrio."
    }
  },
  {
    id: 69,
    name: "Cinco de Oros",
    arcana: "menor",
    suit: "oros",
    number: 5,
    upright: {
      keywords: "Dificultades financieras, pobreza, necesidad, exclusión, pérdida material, inseguridad, preocupación económica, carencia",
      meaning: "Dificultades financieras severas, pobreza temporal, necesidad urgente, exclusión dolorosa, pérdida material significativa, inseguridad económica",
      interpretation: "El Cinco de Oros representa dificultades financieras y la sensación de estar excluido de la abundancia. Aunque la situación es desafiante, es importante recordar que la ayuda está disponible si tienes la humildad de pedirla.",
      advice: "No tengas miedo de pedir ayuda cuando la necesites. Las dificultades financieras son temporales y pueden enseñarte lecciones valiosas sobre la verdadera riqueza."
    },
    reversed: {
      keywords: "Recuperación financiera, mejora económica, ayuda recibida, esperanza renovada, superación de dificultades, abundancia restaurada",
      meaning: "Recuperación financiera completa, mejora económica significativa, ayuda generosamente recibida, esperanza completamente renovada, abundancia totalmente restaurada",
      interpretation: "Invertido, indica que estás recuperándote de dificultades financieras y la situación está mejorando. La ayuda está llegando y tu esperanza en la abundancia se está renovando.",
      advice: "Celebra tu recuperación financiera y recuerda las lecciones aprendidas durante las dificultades. Tu gratitud atraerá aún más abundancia."
    }
  },
  {
    id: 70,
    name: "Seis de Oros",
    arcana: "menor",
    suit: "oros",
    number: 6,
    upright: {
      keywords: "Generosidad, caridad, dar y recibir, equilibrio, justicia financiera, compartir recursos, reciprocidad, ayuda mutua",
      meaning: "Generosidad genuina, caridad amorosa, equilibrio perfecto entre dar y recibir, justicia financiera, reciprocidad natural, ayuda mutua",
      interpretation: "El Seis de Oros representa el equilibrio perfecto entre dar y recibir, y la importancia de la generosidad y la caridad. Es momento de compartir tus recursos con otros y crear un flujo de abundancia que beneficie a todos.",
      advice: "Practica la generosidad equilibrada, dando cuando puedas y recibiendo con gratitud cuando lo necesites. La verdadera abundancia se multiplica cuando se comparte."
    },
    reversed: {
      keywords: "Desequilibrio en dar/recibir, caridad falsa, manipulación financiera, dependencia, ingratitud, egoísmo, explotación",
      meaning: "Desequilibrio severo entre dar y recibir, caridad completamente falsa, manipulación financiera, dependencia tóxica, ingratitud extrema",
      interpretation: "Invertido, indica desequilibrio en las relaciones de dar y recibir, o el uso de la generosidad para manipular a otros. También puede señalar dependencia poco saludable o ingratitud.",
      advice: "Examina tus motivaciones al dar y recibir. La verdadera generosidad no busca control ni crea dependencia, sino que empodera a otros."
    }
  },
  {
    id: 71,
    name: "Siete de Oros",
    arcana: "menor",
    suit: "oros",
    number: 7,
    upright: {
      keywords: "Paciencia, inversión a largo plazo, evaluación, progreso lento, perseverancia, cosecha futura, planificación, crecimiento gradual",
      meaning: "Paciencia infinita, inversión extremadamente a largo plazo, evaluación cuidadosa, perseverancia inquebrantable, planificación meticulosa",
      interpretation: "El Siete de Oros indica que estás en un período de evaluación y crecimiento gradual. Tus inversiones y esfuerzos están dando frutos lentamente, y es importante mantener la paciencia mientras esperas la cosecha completa.",
      advice: "Mantén la paciencia con tus inversiones a largo plazo. El crecimiento gradual y sostenible es más valioso que las ganancias rápidas pero inestables."
    },
    reversed: {
      keywords: "Impaciencia, falta de progreso, inversiones fallidas, abandono prematuro, resultados pobres, frustración, pérdida de fe",
      meaning: "Impaciencia destructiva, falta total de progreso, inversiones completamente fallidas, abandono prematuro de proyectos, resultados extremadamente pobres",
      interpretation: "Invertido, indica impaciencia con el progreso lento o la tentación de abandonar proyectos antes de que den frutos. También puede señalar que las inversiones no están dando los resultados esperados.",
      advice: "No abandones tus proyectos prematuramente por impaciencia. Evalúa objetivamente si necesitas ajustar tu estrategia o simplemente ser más paciente."
    }
  },
  {
    id: 72,
    name: "Ocho de Oros",
    arcana: "menor",
    suit: "oros",
    number: 8,
    upright: {
      keywords: "Maestría, habilidad, dedicación, trabajo duro, perfeccionamiento, artesanía, aprendizaje, disciplina, excelencia",
      meaning: "Maestría completa, habilidad excepcional, dedicación total, trabajo extremadamente duro, perfeccionamiento constante, artesanía exquisita",
      interpretation: "El Ocho de Oros representa dedicación al perfeccionamiento de tus habilidades y la búsqueda de la excelencia en tu trabajo. Es momento de enfocarte en desarrollar tu maestría y crear trabajo de la más alta calidad.",
      advice: "Dedícate al perfeccionamiento de tus habilidades con disciplina y paciencia. La maestría verdadera requiere tiempo, pero los resultados valen la pena."
    },
    reversed: {
      keywords: "Falta de habilidad, trabajo descuidado, pereza, falta de dedicación, mediocridad, atajos, calidad pobre",
      meaning: "Falta severa de habilidad, trabajo extremadamente descuidado, pereza destructiva, falta total de dedicación, mediocridad absoluta",
      interpretation: "Invertido, indica falta de dedicación al desarrollo de habilidades o trabajo de calidad pobre que no cumple con los estándares necesarios. También puede señalar el uso de atajos que comprometen la calidad.",
      advice: "Invierte tiempo y esfuerzo en desarrollar tus habilidades adecuadamente. Los atajos pueden parecer atractivos, pero la calidad siempre se nota."
    }
  },
  {
    id: 73,
    name: "Nueve de Oros",
    arcana: "menor",
    suit: "oros",
    number: 9,
    upright: {
      keywords: "Independencia financiera, lujo, abundancia personal, autosuficiencia, éxito material, refinamiento, logros, prosperidad",
      meaning: "Independencia financiera completa, lujo merecido, abundancia personal desbordante, autosuficiencia total, éxito material extraordinario",
      interpretation: "El Nueve de Oros representa independencia financiera y la capacidad de disfrutar de los frutos de tu trabajo duro. Has alcanzado un nivel de prosperidad que te permite vivir con comodidad y refinamiento, disfrutando de la abundancia que has creado.",
      advice: "Disfruta de la abundancia y independencia que has creado con tu trabajo duro. Has ganado el derecho de vivir con comodidad y refinamiento."
    },
    reversed: {
      keywords: "Dependencia financiera, pérdida de independencia, materialismo vacío, aislamiento, falta de autosuficiencia, superficialidad",
      meaning: "Dependencia financiera severa, pérdida total de independencia, materialismo completamente vacío, aislamiento doloroso, falta completa de autosuficiencia",
      interpretation: "Invertido, indica pérdida de independencia financiera o que el materialismo se ha vuelto vacío y aislante. También puede señalar dependencia poco saludable de otros para tu bienestar material.",
      advice: "Trabaja en recuperar tu independencia financiera y encuentra significado más allá de las posesiones materiales. La verdadera riqueza incluye relaciones y propósito."
    }
  },
  {
    id: 74,
    name: "Diez de Oros",
    arcana: "menor",
    suit: "oros",
    number: 10,
    upright: {
      keywords: "Riqueza familiar, herencia, legado, estabilidad generacional, abundancia compartida, tradición, patrimonio, seguridad familiar",
      meaning: "Riqueza familiar abundante, herencia valiosa, legado duradero, estabilidad generacional sólida, abundancia generosamente compartida",
      interpretation: "El Diez de Oros representa riqueza y estabilidad que se extiende a través de generaciones. Es la culminación de la abundancia material que beneficia no solo a ti, sino a toda tu familia y comunidad, creando un legado duradero.",
      advice: "Piensa en el legado que estás creando para las futuras generaciones. La verdadera riqueza es la que se comparte y perdura a través del tiempo."
    },
    reversed: {
      keywords: "Pérdida familiar, herencia perdida, inestabilidad financiera familiar, conflictos por dinero, legado roto, pobreza generacional",
      meaning: "Pérdida familiar devastadora, herencia completamente perdida, inestabilidad financiera familiar severa, conflictos destructivos por dinero, legado totalmente roto",
      interpretation: "Invertido, indica problemas financieros familiares o conflictos relacionados con herencias y dinero. También puede señalar la pérdida de estabilidad generacional que afecta a toda la familia.",
      advice: "Trabaja en sanar los conflictos familiares relacionados con dinero y enfócate en reconstruir la estabilidad financiera familiar paso a paso."
    }
  },
  {
    id: 75,
    name: "Sota de Oros",
    arcana: "menor",
    suit: "oros",
    number: 11,
    upright: {
      keywords: "Estudiante dedicado, nuevas oportunidades de aprendizaje, manifestación práctica, ambición joven, potencial material, diligencia",
      meaning: "Estudiante extremadamente dedicado, nuevas oportunidades emocionantes de aprendizaje, manifestación práctica exitosa, ambición joven saludable",
      interpretation: "La Sota de Oros representa el estudiante dedicado que está aprendiendo las bases del éxito material. Es momento de enfocarte en el aprendizaje práctico y desarrollar las habilidades que te llevarán hacia la prosperidad futura.",
      advice: "Dedícate al aprendizaje práctico y desarrolla las habilidades que necesitas para el éxito material. Tu diligencia actual determinará tu prosperidad futura."
    },
    reversed: {
      keywords: "Falta de dedicación, oportunidades desperdiciadas, pereza en el aprendizaje, falta de ambición, procrastinación, superficialidad",
      meaning: "Falta total de dedicación, oportunidades constantemente desperdiciadas, pereza extrema en el aprendizaje, falta completa de ambición",
      interpretation: "Invertida, indica falta de dedicación al aprendizaje o desperdicio de oportunidades educativas que podrían llevar al éxito material. También puede señalar pereza o falta de ambición saludable.",
      advice: "Recupera tu dedicación al aprendizaje y no desperdicies las oportunidades de crecimiento. Tu futuro éxito depende de lo que aprendas hoy."
    }
  },
  {
    id: 76,
    name: "Caballero de Oros",
    arcana: "menor",
    suit: "oros",
    number: 12,
    upright: {
      keywords: "Trabajo duro, responsabilidad, confiabilidad, progreso constante, dedicación, paciencia, metodología, perseverancia práctica",
      meaning: "Trabajo extremadamente duro, responsabilidad total, confiabilidad absoluta, progreso constantemente constante, dedicación inquebrantable",
      interpretation: "El Caballero de Oros representa trabajo duro, responsabilidad y progreso constante hacia objetivos materiales. Aunque su avance es lento, es seguro y confiable, construyendo bases sólidas para el éxito duradero.",
      advice: "Mantén tu dedicación al trabajo duro y progreso constante. Tu enfoque metodológico y confiable te llevará al éxito duradero."
    },
    reversed: {
      keywords: "Pereza, irresponsabilidad, falta de progreso, estancamiento, negligencia, falta de dedicación, trabajo descuidado",
      meaning: "Pereza extrema, irresponsabilidad total, falta completa de progreso, estancamiento frustrante, negligencia severa, trabajo extremadamente descuidado",
      interpretation: "Invertido, indica pereza o irresponsabilidad que está impidiendo el progreso hacia objetivos materiales. También puede señalar estancamiento debido a falta de dedicación o trabajo descuidado.",
      advice: "Recupera tu ética de trabajo y responsabilidad. El progreso requiere dedicación constante, no esfuerzos esporádicos."
    }
  },
  {
    id: 77,
    name: "Reina de Oros",
    arcana: "menor",
    suit: "oros",
    number: 13,
    upright: {
      keywords: "Abundancia práctica, generosidad sabia, cuidado maternal, prosperidad compartida, sabiduría financiera, nutrición, estabilidad",
      meaning: "Abundancia extremadamente práctica, generosidad infinitamente sabia, cuidado profundamente maternal, prosperidad generosamente compartida, sabiduría financiera profunda",
      interpretation: "La Reina de Oros representa abundancia práctica y la sabiduría de compartir la prosperidad de manera que nutra y beneficie a otros. Ella combina éxito material con generosidad maternal y crea estabilidad para todos a su alrededor.",
      advice: "Usa tu abundancia y sabiduría práctica para nutrir y beneficiar a otros. Tu generosidad sabia crea un círculo virtuoso de prosperidad compartida."
    },
    reversed: {
      keywords: "Materialismo excesivo, tacañería, negligencia del cuidado, inseguridad financiera, codependencia material, superficialidad",
      meaning: "Materialismo absolutamente excesivo, tacañería extrema, negligencia total del cuidado, inseguridad financiera severa, codependencia material tóxica",
      interpretation: "Invertida, indica que el enfoque en lo material se ha vuelto excesivo o que la inseguridad financiera está afectando tu capacidad de cuidar a otros. También puede señalar tacañería o superficialidad.",
      advice: "Encuentra el equilibrio entre la seguridad material y la generosidad. No permitas que la inseguridad financiera te vuelva tacaña o descuidada con otros."
    }
  },
  {
    id: 78,
    name: "Rey de Oros",
    arcana: "menor",
    suit: "oros",
    number: 14,
    upright: {
      keywords: "Maestría financiera, éxito empresarial, abundancia madura, liderazgo próspero, sabiduría material, generosidad real, imperio construido",
      meaning: "Maestría financiera absoluta, éxito empresarial extraordinario, abundancia completamente madura, liderazgo próspero natural, sabiduría material profunda",
      interpretation: "El Rey de Oros representa la maestría completa en asuntos materiales y financieros. Ha construido un imperio próspero basado en sabiduría práctica y liderazgo sólido, y usa su abundancia para beneficiar a otros y crear estabilidad duradera.",
      advice: "Usa tu maestría financiera y éxito empresarial para crear beneficio duradero para todos. Tu liderazgo próspero puede inspirar y elevar a otros hacia su propia abundancia."
    },
    reversed: {
      keywords: "Corrupción, avaricia extrema, abuso de poder financiero, materialismo tóxico, explotación, tiranía económica, pérdida de valores",
      meaning: "Corrupción severa, avaricia absolutamente extrema, abuso total de poder financiero, materialismo completamente tóxico, explotación sistemática",
      interpretation: "Invertido, indica que el poder financiero se está usando de manera corrupta o que la avaricia extrema está destruyendo relaciones y valores. También puede señalar abuso de poder económico para explotar a otros.",
      advice: "Recuerda que el verdadero éxito incluye integridad y valores éticos. El poder financiero debe ser usado para elevar a otros, no para explotarlos."
    }
  }
];
