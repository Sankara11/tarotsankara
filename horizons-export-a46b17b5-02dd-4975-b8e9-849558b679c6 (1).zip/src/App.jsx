import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import TarotReading from '@/components/TarotReading';
import MenuDelAlma from '@/components/MenuDelAlma';
import Numerology from '@/components/Numerology';
import DreamInterpretation from '@/components/DreamInterpretation';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';

function App() {
  const [activeSection, setActiveSection] = useState('inicio');

  const renderSection = () => {
    switch (activeSection) {
      case 'inicio':
        return <Hero />;
      case 'tarot':
        return <TarotReading />;
      case 'menu':
        return <MenuDelAlma />;
      case 'numerologia':
        return <Numerology />;
      case 'sueños':
        return <DreamInterpretation />;
      case 'contacto':
        return <Contact />;
      default:
        return <Hero />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="cosmic-bg min-h-screen">
        <Header activeSection={activeSection} setActiveSection={setActiveSection} />
        <main className="pt-20">
          <motion.div
            key={activeSection}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
          >
            {renderSection()}
          </motion.div>
        </main>
        <Footer />
        <Toaster />
      </div>
    </div>
  );
}

export default App;